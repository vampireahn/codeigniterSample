<?php
	/**
	 * curl을 간단히 사용하려고 하는 클래스.
	 *
	 * @author sbkang@urbanstreet.me
	 *
	 */
	class Curl {
		/**
		 * @var string url
		 */
		public $url;
		/**
		 * @var string hostName
		 */
		public $hostName;
		/**
		 * @var string httpCode
		 */
		public $httpCode;
		/**
		 * @var string responseData - json raw data
		 */
		public $responseData;

		/**
		 * @var string responseData - json raw data
		 */
		public $jsonData;
		/**
		 * @var array headers - array of http header.
		 */

		public $headers;

		public $apiIP = "";
        public $mngIP = "";
//        public $mngIP_ = "";
//        public $v1IP = "";
//        public $shopIP = "";
//        public $storeIP = "";
//        public $businessIP = "";
//        public $homepageIP = "";

		public function __construct($url, $host_name=null) {
			global $api_ip;

			$this->url = $url;
			$this->apiIP = $api_ip;
			$this->mngIP = $api_ip . "/mng";
//            $this->mngIP = $api_ip;
//            $this->mngIP_ = $api_ip . "/mng_v1";
//            $this->v1IP = $api_ip . "/v1";
//            $this->shopIP = $api_ip . "/shop/v1";
//            $this->storeIP = $api_ip . "/storehome/v1";
//            $this->businessIP = $api_ip . "/business/v1";
//            $this->homepageIP = $api_ip . "/homepage/v1";

			if ( !empty($host_name) )
			{
				$this->hostName = $host_name;
			}
			else
			{
				global $hostName;
				$this->hostName = $hostName;
			}
			$this->headers = array (
				"Host: {$this->hostName}",
				//	'Content-Type: application/x-www-form-urlencoded'
			);
		}

		/**
		 * 200 ok가 아니거나, response에 데이터 없는 경우 에러메시지를 출력한다.
		 * @param resource $session
		 * @return true/false
		 */
		private function __checkError($session) {
			$json_data = json_decode($this->responseData, true);
			if ($this->httpCode != 200 || $this->responseData == false || !isset($json_data)) {
//                $json_data = array(
//                    "code" => $this->httpCode
//                );
				$json_data["code"] = $this->httpCode;
				if (curl_errno($session)) {
					$json_data["error_msg"] =  sprintf("ERROR_IN_CURL: (%d), '%s'\n", curl_errno($session), curl_error($session));
				}
			}
			$this->jsonData = $json_data;
			return $json_data;
		}

		private function make_boundary(){
			srand((double)microtime()*1000000);
			$boundary = "---------------------".substr(md5(rand(0,32000)),0,10);
			return $boundary;
		}

		private function multipart_build_query($fields, $boundary) {
			$retval = '';
			foreach($fields as $key => $value){
				$retval .= "--$boundary\nContent-Disposition: form-data; name=\"$key\"\n\n$value\n";
			}
			$retval .= "--$boundary--";
			return $retval;
		}

		/**
		 * get method
		 * @param array $params
		 * @return bool|array
		 */
		public function get($params=null) {
			if (isset($params)) {
				$session = curl_init($this->url ."?". http_build_query($params));
			} else {
				$session = curl_init($this->url);
			}
			curl_setopt($session, CURLOPT_HTTPHEADER, $this->headers);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($session, CURLOPT_TIMEOUT, 1000);
			curl_setopt($session, CURLOPT_SSL_VERIFYPEER, false);

			$this->responseData = curl_exec($session);
			$this->httpCode = curl_getinfo($session, CURLINFO_HTTP_CODE);
			return $this->__checkError($session);
		}

		/**
		 * put method
		 * @param array $params
		 * @return bool|array
		 */
		public function put($params) {
			$session = curl_init($this->url);
			curl_setopt($session, CURLOPT_HTTPHEADER, $this->headers);
			curl_setopt($session, CURLOPT_CUSTOMREQUEST, "PUT");
			if (isset($params)) {
				curl_setopt($session, CURLOPT_POSTFIELDS, http_build_query($params));
			}
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($session, CURLOPT_TIMEOUT, 1000);

			$this->responseData = curl_exec($session);
			$this->httpCode = curl_getinfo($session, CURLINFO_HTTP_CODE);
			return $this->__checkError($session);
		}

		/**
		 * post method
		 * multipart/form-data 기능 추가.
		 * @param array $params
		 * @param bool $multipart
		 * @return string|bool
		 */
		public function post($params, $multipart=false) {

			$session = curl_init($this->url);
			curl_setopt($session, CURLOPT_POST, true);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($session, CURLOPT_TIMEOUT, 1000);
			curl_setopt($session, CURLOPT_SSL_VERIFYPEER, false);

			if ($multipart) {

				if (!empty($params)) {
					$boundary = $this->make_boundary();
					$data = $this->multipart_build_query($params, $boundary);
					curl_setopt($session, CURLOPT_POSTFIELDS, $data);
					$this->headers[] = "Content-Type: multipart/form-data; boundary={$boundary}";
				}
			} else {
				if (isset($params)) {
					$params = http_build_query($params);
					curl_setopt($session, CURLOPT_POSTFIELDS, $params);
				}
			}
			curl_setopt($session, CURLOPT_HTTPHEADER, $this->headers);

			$this->responseData = curl_exec($session);
			$this->httpCode = curl_getinfo($session, CURLINFO_HTTP_CODE);
//			echo  $this->responseData;

			if ($this->httpCode != 200) {
//                error_log(sprintf("url: %s, error_code: %s", $this->url, $this->httpCode));
				return $this->responseData;
			}

			return $this->__checkError($session);
		}

		/**
		 * delete method
		 * @param array $params
		 * @return bool|array
		 */
		public function delete($params=null) {
			$session = curl_init($this->url);
			curl_setopt($session, CURLOPT_HTTPHEADER, $this->headers);
			curl_setopt($session, CURLOPT_CUSTOMREQUEST, "DELETE");
			if (isset($params)) {
				curl_setopt($session, CURLOPT_POSTFIELDS, http_build_query($params));
			}
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($session, CURLOPT_TIMEOUT, 1000);

			$this->responseData = curl_exec($session);
			$this->httpCode = curl_getinfo($session, CURLINFO_HTTP_CODE);
			echo  $this->responseData;
			return $this->__checkError($session);
		}

		/**
		 * 업로드할 파일과 복잡한 변수를 업로딩한다.
		 * @param resource $session
		 * @param array $assoc
		 * @param array $files
		 * @return bool true/false
		 */
		public static function curl_custom_postfields($session, array $assoc = array(), array $files = array()) {
			// invalid characters for "name" and "filename"
			static $disallow = array("\0", "\"", "\r", "\n");
			// build normal parameters
			foreach ($assoc as $k => $v) {
				$k = str_replace($disallow, "_", $k);
				$body[] = implode("\r\n", array(
					"Content-Disposition: form-data; name=\"{$k}\"",
					"",
					filter_var($v),
				));
			}

			$body = array();
			// build file parameters
			foreach ($files as $k => $v) {
				switch (true) {
					case false === $v = realpath(filter_var($v)):
					case !is_file($v):
					case !is_readable($v):
						continue; // or return false, throw new InvalidArgumentException
				}
				$data = file_get_contents($v);
				$v = call_user_func("end", explode(DIRECTORY_SEPARATOR, $v));
				$k = str_replace($disallow, "_", $k);
				$v = str_replace($disallow, "_", $v);
				$body[] = implode("\r\n", array(
					"Content-Disposition: form-data; name=\"{$k}\"; filename=\"{$v}\"",
					"Content-Type: application/octet-stream",
					"",
					$data,
				));
			}

			// generate safe boundary
			do {
				$boundary = "---------------------" . md5(cls_Curl . phpmt_rand() . microtime());
			} while (preg_grep("/{$boundary}/", $body));

			// add boundary for each parameters
			array_walk($body, function (&$part) use ($boundary) {
				$part = "--{$boundary}\r\n{$part}";
			});

			// add final boundary
			$body[] = "--{$boundary}--";
			$body[] = "";

			// set options
			return @curl_setopt_array($session, array(
				CURLOPT_POST       => true,
				CURLOPT_POSTFIELDS => implode("\r\n", $body),
				CURLOPT_HTTPHEADER => array(
					"Expect: 100-continue",
					"Content-Type: multipart/form-data; boundary={$boundary}", // change Content-Type
				),
			));
		}

		/**
		 * 패러미터 목록을 얻는다.
		 * + ""이 있더라도 key를 생성한다.
		 * + integer 필드는 ""값을 쓸 수 없으므로, nullable에 있는 key는 ""이면 key를 제거한다.
		 * @param string[] $paramKeys 패러미터 이름 목록
		 * @param string[] $paramNullableKeys 저장에서 제외 가능한 패러미터 목록.
		 * @return string assoc array
		 */
		public static function getParams($paramKeys, $paramNullableKeys=null) {
			$data = array();
			foreach ($paramKeys as $key) {
				if (isset($_REQUEST[$key]) || is_array($_REQUEST[$key]))
					$data[$key] = $_REQUEST[$key];

				if (isset($_FILES[$key]) || is_array($_FILES[$key]))
				{
					$file_data = new CURLFile($_FILES[$key]["tmp_name"], $_FILES[$key]["type"], $_FILES[$key]["name"]);
					$data[$key] = $file_data;
				}
			}
			foreach ((array)$paramNullableKeys as $key) {
				if (isset($data[$key]) && $data[$key] === "") {	// 0, 0.0f 등은 값이 설정된 것으로 판단한다.
					unset($data[$key]);
				}
			}
			return $data;
		}

		/**
		 * 변수가 없다면 디폴트값으로 패러미터값을 구하라.
		 * @param string $paramName
		 * @param string $defaultValue
		 * @return string
		 */
		public static function getParam($paramName, $defaultValue) {
			$var = $_REQUEST[$paramName] == "" ? $defaultValue : $_REQUEST[$paramName];
			return $var;
		}

		/**
		 * 파일의 파라메터값
		 * @param string $paramName
		 * @param string $defaultValue
		 * @return string
		 */
		public static function getFileParam($paramName) {
			$fileTemp = $_FILES [$paramName] ["tmp_name"];
			$fileName = $_FILES [$paramName] ["name"];
			$fileType = $_FILES [$paramName] ["type"];
			return new CURLFile($fileTemp,$fileType,$fileName);
		}
	}