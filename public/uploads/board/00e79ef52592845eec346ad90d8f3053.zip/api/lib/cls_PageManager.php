<?
	/**
	 * ------------- ---------------------------------------------------------
	 * PGM name    : CLS_PageManager.php
	 * ------------- ---------------------------------------------------------
	 * PGM comment : 게시물 페이지 관리 클래스
	 * ------------- ---------------------------------------------------------
	 * PGM history : 변경일자   변경자       변경내용
	 * ------------- ---------- ------------ -------------------------------------
	 *                        2012.02.29 vampireahn   최초 개발
	 * ------------- ---------- ------------ -------------------------------------
	 */
	
	class PageManager
	{
		// 초기 세팅해야 하는 값
		var $numPerPage = 10;        # 페이지 당 게시물 갯수
		var $pagePerBlock = 10;      # 한 페이지 당 블럭 갯수
		var $totalRecord = 0;        # 총 게시물 수
		var $currentPage = 0;        # 표시할 현재 페이지
		
		// 페이지 계산 후 사용할 수 있는 값
		var $first;             # 현재 페이지에서 첫번째 게시물
		var $last;              # 현재 페이지에서 마지막 게시물
		var $firstPage;         # 현재 블럭에서 첫번째 페이지
		var $lastPage;          # 현재 블럭에서 마지막 페이지
		var $currentBlock;      # 현재 페이지가 있는 블럭
		var $totalPage;         # 총 페이지 갯수
		var $totalBlock;        # 총 블럭 갯수
		var $topIdx;			# NO
		
		function __construct($numPerPage, $pagePerBlock, $totalRecord, $currentPage)
		{
			$this->numPerPage = $numPerPage;
			$this->pagePerBlock = $pagePerBlock;
			$this->totalRecord = $totalRecord;
			$this->currentPage = $currentPage;
		}
		
		function calcPage()
		{
			// 현재 페이지에서 출력할 게시물 범위 설정
			if ($this->currentPage == 0)
			{
				$this->currentPage = 1;
			}
			
			if ($this->totalRecord == 0)
			{
				$this->first = 1;
				$this->last = 0;
			}
			else
			{
				$this->first = $this->numPerPage * ($this->currentPage - 1);
				$this->last  = $this->numPerPage * $this->currentPage;
				$isNext = $this->totalRecord - $this->last;
				if ($isNext > 0)
				{
					$this->last -= 1;
				}
				else
				{
					$this->last = $this->totalRecord - 1;
				}
			}
			
			// 전체 페이지 수 계산
			$this->totalPage = ceil($this->totalRecord / $this->numPerPage);
			
			// 하단 페이지 링크 계산
			$this->totalBlock = ceil($this->totalPage / $this->pagePerBlock);
			$this->currentBlock = ceil($this->currentPage / $this->pagePerBlock);
			
			$this->firstPage = ($this->currentBlock - 1) * $this->pagePerBlock;
			$this->lastPage  = $this->currentBlock * $this->pagePerBlock;
			
			if ($this->totalBlock <= $this->currentBlock)
			{
				$this->lastPage = $this->totalPage;
			}
			
			$this->topIdx = $this->totalRecord - ( ($this->currentPage -1) * $this->numPerPage );
		}
	}