<?php
	
	/**
	 * ------------- ---------------------------------------------------------
	 * PGM name    : CLS_DBManager.php
	 * ------------- ---------------------------------------------------------
	 * PGM comment : 데이터베이스 매니지먼트 클래스
	 * ------------- ---------------------------------------------------------
	 * PGM history : 변경일자   변경자       변경내용
	 * ------------- ---------- ------------ -------------------------------------
	 * 2012.02.29 vampireahn   최초 개발
	 * 2012.04.05 vampireahn   MY-SQL 자동증가 값 리셋 추가
	 * 2014.12.30 type          $commit 변수 추가. transaction - commit, rollback
	 * 2015.6.16  typeon       mysqli 모듈로 변경.
	 * 2018.2.19 vampireahn     insertPass, updatePass, autoincrementBack 추가
	 * ------------- ---------- ------------ -------------------------------------
	 */
	class DBManager
	{

# public : Connection Parameters
		public $host = "";
		public $database = "";
		public $user = "";
		public $passwd = "";
		public $type = "";
		public $charset = "utf8";

# public : configuration parameters
		public $debug = false;   # Set to true for debugging messages.
		public $haltOnError = "yes";   # "yes" (halt with message), "no" (ignore errors quietly), "report" (ignore error, but spit a warning)

# public : current row number
		public $row = 0;

# public : record set
		protected $record = array();
		protected $recordData = array();

# private : Error infomation
		protected $errorMsg = "";
		protected $errorNo = 0;

# private : Connection and query handle
		/**
		 * @var $mysqli mysqli
		 */
		protected $mysqli = null;
		/**
		 * @var $queryResult mysqli_result
		 */
		protected $queryResult = null;
		/**
		 * @var $locked
		 */
		protected $locked = false;

# public commit
		/**
		 * @var $commit bool autocommit이 아니면, true를 한 후에 반드시 commit or rollback을 해야 한다.
		 */
		public $commit = false;

############################################
# public : Constructor
############################################
		
		public function __construct($db_info = "")
		{
			if ($db_info == "")
			{
				global $db_info;
			}
			
			$this->haltOnError = "no";
			$this->host = trim($db_info['host']);
			$this->database = trim($db_info['dbname']);
			$this->user = trim($db_info['user']);
			$this->passwd = trim($db_info['passwd']);
			$this->type = trim($db_info['type']);
			$this->connect();
		}
		
		public function isSlaveDb()
		{
			return $this->type == "slave" ? true : false;
		}
		
		public function getConncetion()
		{
			return $this->mysqli;
		}
		
		public function getErrorMsg()
		{
			return $this->errorMsg;
		}
		
		public function getErrorNo()
		{
			return $this->errorNo;
		}

############################################
# public : connect to DBMS
############################################
		
		public function connect($database = "", $host = "", $user = "", $passwd = "")
		{
			if ($database == "")
			{
				$database = $this->database;
			}
			if ($host == "")
			{
				$host = $this->host;
			}
			if ($user == "")
			{
				$user = $this->user;
			}
			if ($passwd == "")
			{
				$passwd = $this->passwd;
			}
			if ($this->mysqli == false)
			{
				$this->mysqli = @new mysqli($host, $user, $passwd, $database);
				if (mysqli_connect_errno())
				{
					$this->mysqli = false;  // fetch mysqli error 발생.
					$this->halt(sprintf("Host: %s, User: %s, Msg: %s",
						$host,
						$user,
						mysqli_connect_error()));
					
					return false;
				}
			}
			$this->mysqli->set_charset($this->charset);
			return true;
		}
		
		/**
		 * 트렌젝션을 시작하라. autocommit = false
		 */
		public function startTransaction()
		{
			assert($this->mysqli);
			$this->mysqli->begin_transaction();
		}
		
		/**
		 * 트렌젝션을 종료하라. commit
		 */
		public function commit()
		{
			assert($this->mysqli);
			$this->mysqli->commit();
			$this->mysqli->autocommit(true);
		}
		
		/**
		 * 트렌젝션을 취소하라. rollback
		 */
		public function rollback()
		{
			assert($this->mysqli);
			$this->mysqli->rollback();
			$this->mysqli->autocommit(true);
		}

############################################
# public : discard query result
############################################
		
		public function free()
		{
			if ($this->queryResult)
			{
				$this->queryResult = null;
			}
			$this->record = array();
			$this->row = 0;
		}

############################################
# public : query
############################################
		
		public function query($sql)
		{
			if ($sql == "")
			{
				return false;
			}
			if ($this->mysqli == false)
			{
				return false;
			}
			
			global $g_UsingSqls;
			$g_UsingSqls[] = $sql;
			
			if ($this->debug == true)
			{
				printf("Query String : %s<br>\n", $sql);
			}
			
			$this->queryResult = $this->mysqli->query($sql);
			$this->row = 0;
			$this->errorNo = $this->mysqli->errno;
			$this->errorMsg = $this->mysqli->error;
			if ($this->queryResult == false)
			{
				$this->halt("Invalid SQL : " . $sql);
				return false;
			}
			return $this->queryResult;
		}
		
		/**
		 * SP에서 record를 반환할때 추가적인 결과셋을 없애라.
		 * + mysql에서 SP에서 record를 반환하는 경우 multi result set으로 설정하는 모양이다.
		 */
		public function clearMoreResults()
		{
			while ($this->mysqli->more_results())
			{
				$this->mysqli->next_result();
			}
		}

############################################
# public : move to next record
############################################
		
		public function next($type = "field")
		{
			if (!$this->queryResult || !$this->queryResult->num_rows)
			{
				return false;
			}
			if ($type == "array")
			{
				$this->record = $this->queryResult->fetch_array(MYSQLI_NUM);
			}
			else
			{
				$this->record = $this->queryResult->fetch_array(MYSQLI_ASSOC);
			}
			$this->row += 1;
			$this->errorNo = $this->mysqli->errno;
			$this->errorMsg = $this->mysqli->error;
			if (!$this->record)
			{
				$this->record = array();
				return false;
			}
			return true;
		}

############################################
# public : return value by field name
############################################
		
		public function f($field)
		{
			if (isset($this->record[$field]) == true)
			{
				return $this->record[$field];
			}
			return false;
		}

############################################
# public : return max value by field name
############################################
		
		public function getMaxID($table, $column, $where = "")
		{
			$sql = "SELECT MAX($column) max_id FROM $table WHERE 1=1 AND $where";
			$this->queryResult = $this->mysqli->query($sql);
			if ($this->queryResult == false)
			{
				$this->halt("Invalid SQL : " . $sql);
				return false;
			}
			$record = $this->queryResult->fetch_array(MYSQLI_ASSOC);
			return $record['max_id'];
		}

############################################
# public : return count value by field name
############################################
		
		public function getCountID($table, $column, $where = "")
		{
			if ($where)
			{
				$sql = "SELECT COUNT($column) count_id FROM $table WHERE 1=1 AND $where";
			}
			else
			{
				$sql = "SELECT COUNT($column) count_id FROM $table";
			}
			$this->queryResult = $this->mysqli->query($sql);
			if ($this->queryResult == false)
			{
				$this->halt("Invalid SQL : " . $sql);
				return false;
			}
			$record = $this->queryResult->fetch_array(MYSQLI_ASSOC);
			return $record['count_id'];
		}

###################################################
# public : return all record set
#          This function returns a RecordSet object
###################################################
		
		/**
		 * 현재 insert한 record의 auto_increment_id를 반환하는 함수.
		 *
		 * @see    id가 BIGINT인 경우에는 select last_insert_id();를 사용하도록 권고하고 있다.
		 * @return bool or string (last_inserted_id)
		 */
		public function getInsertId()
		{
			if (!$this->mysqli)
			{
				return false;
			}
			return (string)$this->mysqli->insert_id;
		}
		
		public function getInsertIds()
		{
			if (!$this->mysqli)
			{
				return false;
			}
			return (array)$this->mysqli->insert_id;
		}

############################################
# public : return number of result rows
############################################
		
		public function getRecordCount()
		{
			if (!$this->queryResult)
			{
				return false;
			}
			return $this->queryResult->num_rows;
		}

###################################################
# public : return query data record set
###################################################
		
		/**
		 * 전체 rows 목록을 구하라.
		 * @param string $sql
		 * @return array|bool
		 */
		public function getRecords($sql)
		{
			$res = $this->query($sql);
			if ($res === false)
			{
				return false;
			}
			$result = array();
			while ($this->next())
			{
				$result[] = array_map(function ($val)
				{
					return is_null($val) ? "" : $val;
				},
					$this->record);
			}
			$this->free();
			return $result;
		}
		
		/**
		 * 한 row만 반환하라.
		 * @param string $sql
		 * @param string $column
		 * @return array|bool|null|resource
		 */
		public function getRecord($sql, $column = "")
		{
			$res = $this->query($sql);
			if ($res === false)
			{
				return false;
			}
			$this->next();
			$ret = ($column == "") ? array_map(function ($val)
			{
				return is_null($val) ? "" : $val;
			}, $this->record)
				: $this->record[$column];
			$this->free();
			return $ret;
		}

##########################################################
# public : array is insert(update) data :: return result
##########################################################
		/** 비밀번호가 포함 되지 않은 INSERT */
		public function insertData($table, $data)
		{
			
			$inputData = '';
			$inputKey = '';
			foreach ($data as $key => $value)
			{
				
				if ($inputKey != "")
				{
					$inputKey .= ",";
				}
				$inputKey .= "$key";
				
				if ($inputData != "")
				{
					$inputData .= ",";
				}
				
				if ($value == "NULL" || $value == "NOW()")
				{
					$inputData .= "$value";
				}
				else
				{
					$inputData .= "'$value'";
				}
			}
			
			$sql = "INSERT  INTO $table ($inputKey) VALUES ($inputData)";
			
			return $this->query($sql);
		}
		
		/** 비밀번호가 포함된 INSERT */
		public function insertPassData($table, $data)
		{
			
			$inputData = '';
			$inputKey = '';
			foreach ($data as $key => $value)
			{
				
				if ($inputKey != "")
				{
					$inputKey .= ",";
				}
				$inputKey .= "$key";
				
				if ($inputData != "")
				{
					$inputData .= ",";
				}
				
				if ($value == "NULL" || $value == "NOW()")
				{
					$inputData .= "$value";
				}
				else
				{
					$keyWord = explode("_", $key);
					if ($keyWord[1] == "PASS")
					{
						$inputData .= "md5('$value')";
					}
					else
					{
						$inputData .= "'$value'";
					}
				}
			}
			
			$sql = "INSERT  INTO $table ($inputKey) VALUES ($inputData)";
			
			return $this->query($sql);
		}
		
		/** 비밀번호가 포함되지 않은 UPDATE */
		public function updateData($table, $data, $where)
		{
			
			$inputData = '';
			foreach ($data as $key => $value)
			{
				if ($inputData != "")
				{
					$inputData .= ",";
				}
				
				if ($value == "NULL" || $value == "NOW()")
				{
					$inputData .= "$key = $value";
				}
				else
				{
					$inputData .= "$key = '$value'";
				}
			}
			
			$sql = "UPDATE $table SET $inputData WHERE $where";
			
			return $this->query($sql);
		}
		
		/** 비밀번호가 포함된 UPDATE */
		public function updatePassData($table, $data, $where)
		{
			
			$inputData = '';
			foreach ($data as $key => $value)
			{
				if ($inputData != "")
				{
					$inputData .= ",";
				}
				
				if ($value == "NULL" || $value == "NOW()")
				{
					$inputData .= "$key = $value";
				}
				else
				{
					$keyWord = explode("_", $key);
					if ($keyWord[1] == "PASS")
					{
						$inputData .= "$key = md5('$value')";
					}
					else
					{
						$inputData .= "$key = '$value'";
					}
				}
			}
			
			$sql = "UPDATE $table SET $inputData WHERE $where";
			
			return $this->query($sql);
		}

############################################
# public : AUTO_INCREMENT Reset
############################################
		
		public function autoincrementReset($table)
		{
			$sql = "ALTER TABLE $table AUTO_INCREMENT = 0";
			return $this->query($sql);
		}
		
		public function autoincrementBack($table, $idx)
		{
			$sql = "ALTER TABLE $table AUTO_INCREMENT = $idx";
			return $this->query($sql);
		}

############################################
# public : lock table
############################################
		
		public function lock($mode)
		{
			$sql = "LOCK TABLES " . $mode;
			if ($this->query($sql) == false)
			{
				return false;
			}
			return true;
		}
		
		/**
		 * 테이블락 여부를 설정하라.
		 * @param bool $locked
		 */
		public function setLocked($locked)
		{
			$this->locked = $locked;
		}

############################################
# public : unlock table
############################################
		
		public function unlock()
		{
			if (!$this->locked)
			{
				return true;
			}
			$sql = "UNLOCK TABLES";
			if ($this->query($sql) == false)
			{
				return false;
			}
			return true;
		}

############################################
# public : disconnect
############################################
		
		public function disconnect()
		{
			$this->mysqli->close();
		}

############################################
# private : error processing
############################################
		
		public function halt($msg)
		{
			if (!$this->mysqli)
			{
				return;
			}
			$this->errorMsg = $this->mysqli->errno;
			$this->errorNo = $this->mysqli->error;
			error_log("ERROR_NO:{$this->errorNo}, MSG: {$this->errorMsg}");
			$this->error_log_separately($msg);
			if ($this->haltOnError == "no")
			{
				return;
			}
			$this->haltMsg($msg);
			if ($this->haltOnError != "report")
			{
				die("Session halted.");
			}
		}

############################################
# private : show halt message
############################################
		
		public function haltMsg($msg)
		{
			//require_once(_SPATH_WWW."include/inc_programError.php");
			echo(<<<MSG
			<br>
			<table cellspacing=1 cellpadding=2 border=1 width=70%>
			<tr>
				<td bgcolor=lightgrey align=center><font size=2>[{$this->errorNo}] {$this->errorMsg} </font></td>
			</tr>
			<tr>
				<td bgcolor=white align=left><font size=2>{$msg}</font></td>
			</tr>
			</table>
			<br>
MSG
			);
		}
		
		/**
		 * 긴 메시지를 15라인 문장으로 나눠서 error_log에 출력하라.
		 * @param string $msg
		 * @param int $line_num
		 */
		protected function error_log_separately($msg, $line_num = 15)
		{
			$lines = explode(PHP_EOL, $msg);
			for ($i = 0; $i <= count($lines) / $line_num; $i++)
			{
				$msg_lines = array_slice($lines, $i * $line_num, $line_num);
				array_map(function ($val)
				{
					return ltrim($val);
				}, $msg_lines);
				error_log("\n" . implode(PHP_EOL, $msg_lines));
			}
		}
	}
