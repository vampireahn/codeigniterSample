<?
	/**
	 * ------------- ---------------------------------------------------------
	 * PGM name    : inc_UtilFunc.php
	 * ------------- ---------------------------------------------------------
	 * PGM comment : 각종 유용한 함수 정의 파일
	 * 정의 된 함수는 범용 라이브러리 함수임.
	 * ------------- ---------------------------------------------------------
	 * PGM history : 변경일자   변경자       변경내용
	 * ------------- ---------- ------------ -------------------------------------
	 * 2012.02.29 vampireahn   최초 개발
	 * ------------- ---------- ------------ -------------------------------------
	 */
	
	/** 파라메터 설정 */
	
	function param($param)
	{
		$parameter = "";
		
		foreach ((array)$param as $pKey => $pValue)
		{
			if ($pKey != "" && $pValue != "")
			{
				if ($parameter != "")
				{
					$parameter .= "&";
				}
				
				$parameter .= $pKey . "=" . $pValue;
			}
		}
		
		return "&{$parameter}";
	}
	
	function param2($page, $param)
	{
		$parameter = "";
		
		$param[page] = $page;
		
		foreach ((array)$param as $pKey => $pValue)
		{
			if ($pKey != "" && $pValue != "")
			{
				if ($parameter != "")
				{
					$parameter .= "&";
				}
//			    else
//			    {
//				    $parameter .= "&";
//			    }
				
				$parameter .= $pKey . "=" . $pValue;
			}
		}
		
		return "?{$parameter}";
	}
	
	function checkAdminMenuAuth($pgm_name = '')
	{
		
		if ($pgm_name == '')
		{
			return;
		}
		
		// 해당 권한지 있는지 확인
		
		global $AuthKit;
		
		if ($AuthKit->isAdmin() == false)
		{
			echo("
				<script>
				alert('관리자만 이용할 수 있습니다.');
				parent.top.location = '/admin/';
				</script>
			");
			exit;
		}
	}
	
	
	/* 문자열을 일정 길이만큼 자르고 뒷 부분에 $suffix문자열을 덧붙인다. */
	function cutString($text, $length, $suffix = "..")
	{
		if (strlen($text) <= $length)
		{
			$result = $text;
		}
		else
		{
			$result = inc_UtilFunc . phpmb_strcut(strip_tags($text), 0, $length, "utf8") . $suffix;
		}
		
		return $result;
	}
	
	/* 자바스크립트 경고창을 표시한다.
	   - 돌아가는 페이지를 명시하지 않으면 이전 페이지로 자동 설정
	   - 돌아가는 페이지를 none으로 하면 메세지만 표시하고 페이지 포워딩은 하지 않는다.
	*/
	function showMsg($msg, $url = "-1")
	{
		if ($url == "-1")
		{
			$back_url = "history.back();";
		}
		else if ($url == "none")
		{
			$back_url = "";
		}
		else if ($url == "popup")
		{
			$back_url = "window.close();";
		}
		else
		{
			$back_url = "this.location.replace('$url');";
		}
		
		$msg = ($msg) ? "alert('$msg');" : "";
		
		@header("Content-Type: text/html; charset=utf-8");
		echo("<script>" . $msg . $back_url . "</script>");
	}
	
	
	function get_ext($filename)
	{
		$filename = explode(".", basename($filename));
		return strtolower($filename[count($filename) - 1]);
	}
	
	/* 메일을 전송한다. */
	function sendMail2($to_email, $from_email, $from_name, $subject, $message)
	{
		header("Content-Type: text/html; charset=euc-kr");
		$headers = "MIME-Version: 1.0\r\n";
		$headers .= "Content-type: text/html; charset=euc-kr\r\n";
		$headers .= "From: $from_name <$from_email>\r\n";
		$headers .= "Reply-To : <$from_email>\n";
		$headers .= "X-Mailer: PHP " . phpversion() . "\n";
		$headers .= "X-Priority: 1\n";
		
		
		if (preg_match('!^[\w\d\_\.\-]+\@((?:[\w\d\_\-]+\.)+(?:[\w]+))$!i', trim($to_email), $to) == 1 && $subject != null)
		{
//			return mail($to[0], $subject, $message, $headers);
			mail($to[0], $subject, $message, $headers);
		}
		return "Message Sent OK";
	}
	
	function sendMailUTF($to_email, $subject, $message)
	{
		
		$from_email = "";
		$from_name = "";
		
		$headers = "MIME-Version: 1.0\n";
		$headers .= "Content-Type: text/html; charset=UTF-8 \n";
		$headers .= "From: " . "=?UTF-8?B?" . base64_encode($from_name) . "?=<" . $from_email . ">\n";
		$headers .= "Reply-To : <$from_email>\n";
		$headers .= "X-Mailer: PHP " . phpversion() . "\n";
		
		$subject = "=?UTF-8?B?" . base64_encode($subject) . "?=\n";
		
		if (preg_match('!^[\w\d\_\.\-]+\@((?:[\w\d\_\-]+\.)+(?:[\w]+))$!i', trim($to_email), $to) == 1 && $subject != null)
		{
			return mail($to_email, $subject, $message, $headers);
		}
	}
	
	function pubcode($group, $db)
	{
		$sql = "SELECT * FROM tbl_pubcode WHERE pub_group = '$group' AND pub_useYN = 'Y' ORDER BY pub_orderNo";
		$db->query($sql);
		while ($db->next())
		{
			$row[value] = $db->f("pub_name");
			$row[name] = $db->f("pub_desc");
			$record[] = $row;
		}
		return $record;
	}
	
	function _option($selecter, $data)
	{
		foreach ($data as $row)
		{
			$sel = ($row[value] == $selecter) ? "selected" : "";
			$str .= "<option value='$row[value]' $sel>$row[name]</option>";
		}
		return $str;
	}
	
	
	/* 새로운 쪽지가 몇 통 있는지 리턴한다. */
	function getNewNote($user_id, $db)
	{
		$sql = "SELECT count(*) c FROM tbl_note WHERE user_id='$user_id' AND note_box='recieve' AND confirm='N'";
		$db->query($sql);
		$db->next();
		$new_note = $db->f("c");
		
		return $new_note;
	}
	
	/*
		카운터를 증가시킨다. 쿠키를 세팅하여 중복 증가를 방지한다.
	*/
	
	function addCounter($db)
	{
		global $cookie_check_visit;   // 카운터 중복 증가 방지용 쿠키변수
		
		$year = date("Y", time());
		$month = date("m", time());
		$day = date("d", time());
		$time = date("H", time());
		
		if ($cookie_check_visit == "")
		{
			$sql = "SELECT count(*) c FROM tbl_counter WHERE year='$year' AND month='$month' AND day='$day' AND time='$time'";
			$db->query($sql);
			$db->next();
			
			if ($db->f("c") == 0)
			{
				$sql = "INSERT INTO tbl_counter (year, month, day, time, count) VALUES('$year', '$month', '$day', '$time', 1)";
			}
			else
			{
				$sql = "UPDATE tbl_counter SET count=count+1 WHERE year='$year' AND month='$month' AND day='$day' AND time='$time'";
			}
			
			$db->query($sql);
			
			$agent = $_SERVER['HTTP_USER_AGENT'];
			$refer = $_SERVER['HTTP_REFERER'];
			
			$refer = str_replace("http://", "", $refer);
			$refer = str_replace("https://", "", $refer);
			$str = explode("/", $refer);
			$refer = $str[0];
			
			$sql = "
			INSERT INTO tbl_counter_log
				(year, month, day, time,agent, refer)
			VALUES
				('$year', '$month', '$day', '$time', '$agent', '$refer');
			";
			$db->query($sql);
			
			setcookie("cookie_check_visit", "Y");
		}
	}
	
	/*
		카운터를 가져온다. 오늘 방문자수와 전체 방문자수를 연관배열에 넣어서 리턴한다.
	*/
	
	function getCounter($db)
	{
		$year = date("Y", time());
		$month = date("m", time());
		$day = date("d", time());
		$time = date("H", time());
		
		// 오늘 방문자
		$sql = "SELECT sum(count) s FROM tbl_counter WHERE year='$year' AND month='$month' AND day='$day'";
		$db->query($sql);
		$db->next();
		$counter_today = $db->f("s");
		if ($counter_today == "")
		{
			$counter_today = 0;
		}
		
		// 전체 방문자
		$sql = "SELECT sum(count) s FROM tbl_counter";
		$db->query($sql);
		$db->next();
		$counter_total = $db->f("s");
		if ($counter_total == "")
		{
			$counter_total = 0;
		}
		
		$counter[today] = $counter_today;
		$counter[total] = $counter_total;
		
		return $counter;
	}
	
	function arr2json($a = false)
	{
		if (is_null($a))
		{
			return 'null';
		}
		if ($a === false)
		{
			return 'false';
		}
		if ($a === true)
		{
			return 'true';
		}
		if (is_scalar($a))
		{
			if (is_float($a))
			{
				// Always use "." for floats.
				return floatval(str_replace(',', '.', strval($a)));
			}
			else if (is_numeric($a))
			{
				return $a;
			}
			
			
			if (is_string($a))
			{
				static $jsonReplaces = array(array("\\", "/", "\n", "\t", "\r", "\b", "\f", '"'), array('\\\\', '\\/', '\\n', '\\t', '\\r', '\\b', '\\f', '\"'));
				return '"' . str_replace($jsonReplaces[0], $jsonReplaces[1], $a) . '"';
			}
			else
			{
				return $a;
			}
		}
		
		$isList = true;
		
		for ($i = 0, reset($a), $cnt = count($a); $i < $cnt; $i++, next($a))
		{
			if (key($a) !== $i)
			{
				$isList = false;
				break;
			}
		}
		
		$result = array();
		
		if ($isList)
		{
			foreach ($a as $v)
			{
				$result[] = arr2json($v);
			}
			return '[' . join(',', $result) . ']';
		}
		else
		{
			foreach ($a as $k => $v)
			{
				$result[] = arr2json($k) . ':' . arr2json($v);
			}
			return '{' . join(',', $result) . '}';
		}
	}
	
	function getCodeNames($db, $codeStr)
	{
		$sql = " SELECT pub_codeName FROM tbl_pubcode WHERE pub_useYN = 'Y' AND pub_code in ('$codeStr') ";
		$db->query($sql);
		while ($db->next())
		{
			$tmpStr[] .= $db->record[pub_codeName];
		}
		if (count($tmpStr) > 0)
		{
			$tmpStr = implode(",", $tmpStr);
		}
		return $tmpStr;
	}
	
	function selecter($sltName, $sltValue)
	{
		global $$sltName;
		if ($$sltName == $sltValue)
		{
			echo "selected";
		}
	}
	
	function _selecter($obj, $slt_val)
	{
		foreach ($obj as $k => $v)
		{
			$slt = ($slt_val == (string)$k) ? " selected" : "";
			$str .= "<option value='$k' $slt>$v</option>";
		}
		return $str;
	}
	
	
	function comp($data, $val, $str)
	{
		$val2 = explode(";", $val);
		
		foreach ($val2 as $v)
		{
			if ($data == $v)
			{
				return $str;
			}
		}
	}
	
	function string_replace($str, $viewcnt, $suffix = "*")
	{
		
		$strlength = strlen($str);
		$newstr = substr($str, 0, $viewcnt);
		
		for ($i = $viewcnt + 1; $i <= $strlength; $i++)
		{
			$newstr .= $suffix;
		}
		
		return $newstr;
		
	}
	
	// SMS 전송(전송타입, 내용, 지점번호, 고객핸드폰번호, 전송일, SMS 전송타입 ,지점아이디, 회원아이디, 전송자구분 B or U )
	function sms_send3($sendtype, $msg, $callback, $hp, $set_date, $type, $brc_id, $mem_id, $sms_sender, $file_cnt = 0, $file_path1 = "", $file_path2 = "", $file_path3 = "", $file_path1_siz = "", $file_path2_siz = "", $file_path3_siz = "")
	{
		global $db;
		
		if (!$set_date)
		{
			$set_date = date("Y-m-d H:i:s");
		}
		$hp = str_replace("-", "", $hp);
		$callback = str_replace("-", "", $callback);
		
		// sms 전송테이블
		if ($sendtype == "SMS")
		{
			$sql1 = "
				INSERT INTO SC_TRAN
					(TR_SENDDATE, TR_SENDSTAT, TR_PHONE, TR_CALLBACK, TR_MSG, TR_MSGTYPE, TR_ETC1, TR_ETC2)
				VALUES
					('$set_date','0','$hp','$callback','$msg','0', '$type', '$brc_id')
			";
			$result = $db->query($sql1);
		}
		// MMS 전송테이블
		elseif ($sendtype == "MMS")
		{
			$sql1 = "
				INSERT INTO mms_msg
					(PHONE, CALLBACK, STATUS, REQDATE, MSG, FILE_CNT, FILE_CNT_REAL, FILE_PATH1, FILE_PATH1_SIZ, FILE_PATH2, FILE_PATH2_SIZ, FILE_PATH3, FILE_PATH3_SIZ, TYPE)
				VALUES
					('$hp','$callback','0','$set_date','$msg','$file_cnt','$file_cnt','$file_path1','$file_path1_siz','$file_path2','$file_path2_siz','$file_path3','$file_path3_siz','0')";
			$result = $db->query($sql1);
		}
		//echo $sql1."<br>";
		
		
		// sms 로그 테이블
		$sql2 = "
			INSERT INTO j2t_sms_log
				(brc_id, mem_id, sms_no, sms_type, sms_sender, sms_callNo, sms_mms, sms_desc, sms_sendDate, sms_regDate)
			VALUES
				('$brc_id','$mem_id','$hp','$type','$sms_sender','$callback','$sendtype','$msg','$set_date',now())
		";
		$db->query($sql2);
		//echo $sql2."<br>";
		
		
		// sms 통계
		$sms_date = substr($set_date, 0, 10);
		if ($sendtype == "SMS")
		{
			$sql3 = "
				INSERT INTO j2t_sms_stat
					(sms_date, brc_id, sms_count, sms_mmsCount)
				VALUES
					('$sms_date','$brc_id','1','0')
				ON DUPLICATE KEY UPDATE sms_count = sms_count + 1
			";
			$db->query($sql3);
		}
		elseif ($sendtype == "MMS")
		{
			$sql3 = "
				INSERT INTO j2t_sms_stat
					(sms_date, brc_id, sms_count, sms_mmsCount)
				VALUES
					('$sms_date','$brc_id','0','1')
				ON DUPLICATE KEY UPDATE sms_mmsCount = sms_mmsCount + 1";
			$db->query($sql3);
		}
		return $result;
		
	}
	
	// SMS 전송(전송타입, 내용, 지점번호, 고객핸드폰번호, 전송일, SMS 전송타입 ,지점아이디, 회원아이디, 전송자구분 B or U )
	function sms_send($sendtype, $msg, $callback, $hp, $set_date, $type, $brc_id, $mem_id, $sms_sender, $file_cnt = 0, $file_path1 = "", $file_path2 = "", $file_path3 = "", $file_path1_siz = "", $file_path2_siz = "", $file_path3_siz = "")
	{
		global $db;
		
		if (!$set_date)
		{
			$set_date = date("Y-m-d H:i:s");
		}
		$hp = str_replace("-", "", $hp);
		$callback = str_replace("-", "", $callback);
		
		// sms 전송테이블
		if ($sendtype == "SMS")
		{
			$sql1 = "
				INSERT INTO MSG_DATA
					(req_date, cur_state, call_to, call_from, sms_txt, msg_type)
				VALUES
					('$set_date','0','$hp','$callback','$msg','4')
			";
			$result = $db->query($sql1);
		}
		// MMS 전송테이블
		elseif ($sendtype == "MMS")
		{
			if ($file_cnt)
			{
				$file_cnt = $file_cnt + 1;
			}
			
			if ($file_path1)
			{
				$file_name1 = "/home/sms/file/" . $file_path1;
				$file_type1 = "IMG";
			}
			if ($file_path2)
			{
				$file_name2 = "/home/sms/file/" . $file_path2;
				$file_type2 = "IMG";
			}
			if ($file_path3)
			{
				$file_name3 = "/home/sms/file/" . $file_path3;
				$file_type3 = "IMG";
			}
			
			$sql1 = "
				INSERT INTO MMS_CONTENTS_INFO
					(file_cnt, mms_body, file_type1, file_type2, file_type3, file_name1, file_name2, file_name3)
				VALUES
					('$file_cnt', '$msg', '$file_type1', '$file_type2', '$file_type3', '$file_name1', '$file_name2', '$file_name3' )
			";
			$db->query($sql1);
			$cont_seq = mysql_insert_id();
			
			$sql1 = "
				INSERT INTO MSG_DATA
					(req_date, cur_state, call_to, call_from, sms_txt, msg_type, cont_seq)
				VALUES
					('$set_date','0','$hp','$callback','','6','$cont_seq')
			";
			$result = $db->query($sql1);
		}
		
		// sms 로그 테이블
		$sql2 = "
			INSERT INTO j2t_sms_log
				(brc_id, mem_id, sms_no, sms_type, sms_sender, sms_callNo, sms_mms, sms_desc, sms_sendDate, sms_regDate)
			VALUES
				('$brc_id','$mem_id','$hp','$type','$sms_sender','$callback','$sendtype','$msg','$set_date',now())
		";
		$db->query($sql2);
		
		
		// sms 통계
		$sms_date = substr($set_date, 0, 10);
		if ($sendtype == "SMS")
		{
			$sql3 = "
				INSERT INTO j2t_sms_stat
					(sms_date, brc_id, sms_count, sms_mmsCount)
				VALUES
					('$sms_date','$brc_id','1','0')
				ON DUPLICATE KEY UPDATE sms_count = sms_count + 1
			";
			$db->query($sql3);
		}
		elseif ($sendtype == "MMS")
		{
			$sql3 = "
				INSERT INTO j2t_sms_stat
					(sms_date, brc_id, sms_count, sms_mmsCount)
				VALUES
					('$sms_date','$brc_id','0','1')
				ON DUPLICATE KEY UPDATE sms_mmsCount = sms_mmsCount + 1";
			$db->query($sql3);
		}
		return $result;
		
	}
	
	function _sms_send($sms)
	{
		if (isset($sms["send_date"]) == false)
		{
			$sms["send_date"] = date("Y-m-d H:i:s");
		}
		
		// SMS 전송(전송타입, 내용 msg, 지점번호 callback, 고객핸드폰번호 rev_hp, 전송일 send_date, SMS 전송타입 sms_type ,지점아이디 brc_id, 회원아이디 rsv_mem_id, 전송자구분 B or U  sender_type)
		return sms_send("SMS", $sms["msg"], $sms["callback"], $sms["rsv_hp"], $sms["send_date"], $sms["sms_type"], $sms["brc_id"], $sms["rsv_mem_id"], $sms["sender_type"]);
	}
	
	function new_data($regdate, $day = 3)
	{
		$baseday = mktime(0, 0, 0, date("m"), date("d") - $day, date("Y"));
		$baseday = date("Y-m-d H:i:s", $baseday);
		
		if ($baseday < $regdate)
		{
			$new_mark = "<img src='/images/btn/btn_new.gif' class='img' title='새글' />";
		}
		else
		{
			$new_mark = "";
		}
		
		return $new_mark;
		
	}
	
	/* 달력데이터 배열로 받음 */
	function make_calender($year, $month, $day, $limit = 0)
	{
		$curr = strtotime("$year-$month-$day");
		$yyyy = date("Y", $curr);
		$mm = date("m", $curr);
		$dd = date("d", $curr);
		
		$fd = date("w", strtotime("$yyyy-$mm-01")); // 1일의 요일
		$fl = date("t", strtotime("$yyyy-$mm-01")); // 해당달 일수
		
		$fd = $fd * -1;
		
		$data = array();
		
		$last = 42 + $fd;
		
		$cnt = $div = 0;
		for ($i = $fd + 1; $i <= $last; $i++)
		{
			if ($i < 1 || $i > $fl)
			{
				$data[$i]["day"] = "";
			}
			else
			{
				$str_i = $i < 10 ? "0" . $i : $i;
				$data[$i]["full_day"] = $yyyy . "-" . $mm . "-" . $str_i;
				$data[$i]["day"] = $i;
				
				if ($dd == $i)
				{
					$data[$i]["opt"] = "today";
				}
			}
			
			$cnt++;
		}
		
		/* 선택 가능 날짜 정하기 */
		if ($limit > 0)
		{
			
			for ($i = 0; $i < $limit; $i++)
			{
				if (date("w", strtotime("+" . $i . "day")) == 0)
				{
					continue;
				} // 일요일
				$allow_day[] = date("Y-m-d", strtotime("+" . $i . "day"));
			}
			
			foreach ($data as $key => $row)
			{
				$data[$key]["status"] = (in_array($row["full_day"], $allow_day)) ? "Y" : "N";
			}
		}
		
		
		return $data;
	}
	
	
	function make_timetable($st, $ed, $gap)
	{
		for ($i = strtotime($st); $i <= strtotime($ed); $i += (60 * $gap))
		{
			$time = date("H:i", $i);
			$data[$time] = array("time" => $time, "status" => "");
		}
		return $data;
	}
	
	/* 페이지별 통계 */
	function menu_statistic($menu_self, $menu_name)
	{
		
		global $db;
		
		$menu_date = date("Y-m-d");
		$sql = "INSERT INTO j2t_menu_counter SET mnu_date='$menu_date', mnu_page='$menu_self', mnu_name='$menu_name', mnu_counter=1 ON DUPLICATE KEY UPDATE mnu_counter = mnu_counter + 1";
		$db->query($sql);
	}
	
	
	function f_select($name, $data, $title = "", $slt_data = "")
	{
		$str = "<select name=\"" . $name . "\" id=\"\" style=\"vertical-align:bottom;height:21px;\">";
		
		if (is_array($data))
		{
			if ($title != "")
			{
				$str .= "<option value=\"\">" . $title . "</option>";
			}
			
			if ($slt_data == "")
			{
				$slt_data = $_GET[$name];
			}
			
			$str .= _selecter($data, $slt_data);
		}
		$str .= "</select>";
		
		return $str;
	}
	
	function f_radio($name, $data, $idx = 0)
	{
		if ($_GET[$name] == "")
		{
			$initFlag = true;
		}
		
		$cnt = 0;
		foreach ($data as $k => $v)
		{
			
			$checked = ($_GET[$name] == (string)$k) ? "checked" : "";
			if ($cnt == $idx && $initFlag == true)
			{
				$checked = "checked";
			}
			
			$str .= "<input type=\"radio\" name=\"" . $name . "\" value=\"$k\" class=\"\" $checked /> $v ";
			$cnt++;
		}
		return $str;
	}
	
	function f_checkbox($name, $data, $basic_check = "N", $idx = 0)
	{
		
		if ($_GET[$name] == "" && $basic_check == "Y")
		{
			$initFlag = true;
		}
		
		$cnt = 0;
		foreach ($data as $k => $v)
		{
			$checked = ($_GET[$name] && in_array($k, $_GET[$name])) ? "checked" : "";
			if ($cnt == $idx && $initFlag == true)
			{
				$checked = "checked";
			}
			
			$str .= "<input type=\"checkbox\" name=\"" . $name . "[]\" value=\"$k\" title=\"\" class=\"\" $checked /> $v ";
			$cnt++;
		}
		return $str;
	}
	
	function f_inputbox($name, $data, $width)
	{
		return $str;
	}
	
	/* 이미지 정보 */
	function get_image_info($src)
	{
		$img_info = @getimagesize($src);
		
		$img["width"] = $img_info[0];
		$img["height"] = $img_info[1];
		$img["type"] = $img_info[2];
		$img["mime"] = $img_info["mime"];
		
		return $img;
	}
	
	function chkValue($data)
	{
		
		$result = array();
		if (is_array($data))
		{
			foreach ($data as $key => $vlu)
			{
				$vlu = str_replace("<", "&lt;", $vlu);
				$vlu = str_replace(">", "&gt;", $vlu);
				$vlu = str_replace("\"", "&quot;", $vlu);
				
				$result[$key] = $vlu;
			}
		}
		
		return $result;
	}
	
	function stats_auth($referer)
	{
		
		if ($referer != $_SESSION["stats_auth_url"] || !$_SESSION["stats_auth_flag"] && ($_SESSION["stats_auth_time"] + _STATS_LOGOUT_TIME < time()))
		{
			$_SESSION["stats_auth_flag"] = false;
			$_SESSION["stats_logout_time"] = 0;
			$_SESSION["stats_auth_url"] = "";
			
			include(_SPATH_WWW . "statistics/stats_login.php");
			exit;
		}
		else
		{
			$_SESSION["stats_auth_time"] = time();
		}
	}
	
	function str_week_day($wday)
	{
		
		$weekday = array("일", "월", "화", "수", "목", "금", "토");
		
		$rtn = $weekday[date("w", strtotime($wday))];
		
		return $rtn;
		
	}
	
	function limit_search_date($stl_type, $sdate, $edate)
	{
		if ($sdate >= $edate)
		{
			$min_date = $edate;
			$max_date = $sdate;
		}
		else
		{
			$min_date = $sdate;
			$max_date = $edate;
		}
		
		$sd = strtotime("-3 month");
		$thisyear = date("Y");
		$thismonth = date("m");
		$st = explode("-", $min_date);
		$et = explode("-", $max_date);
		
		$_SESSION["stats_auth_rate"] = "1";
		
		if ($thisyear != $st[0])
		{
			if ($thismonth < 3)
			{
				if ($min_date < $sd)
				{
					if ($stl_type == "B")
					{
						showMsg("검색기간은 " . date("Y-m-d", $sd) . " 부터 가능합니다.", "-1");
						exit;
					}
					else if ($_SESSION["stats_auth_level"] == "g")
					{
						$_SESSION["stats_auth_rate"] = "0.8565";
					}
				}
			}
			else
			{
				if ($stl_type == "B")
				{
					showMsg("검색기간은 $thisyear 년 부터 가능합니다.", "-1");
					exit;
				}
				else if ($_SESSION["stats_auth_level"] == "g")
				{
					$_SESSION["stats_auth_rate"] = "0.8565";
				}
			}
		}
	}
	
	/**********************************************************************
	 * 현재의 script_name 위치에서 depth 위치에 있는 폴더명을 구합니다.
	 * 주소URL : "http://www.abc.com/community/every/freetalk/"
	 * ex) ScriptName(2)
	 * [결과] every
	 *********************************************************************/
	function ScriptName($pDept)
	{
		$SCRIPT_NAME = Trim($_SERVER['SCRIPT_NAME']);
		$ScriptName = Trim($SCRIPT_NAME);
		
		$pos = explode("/", $ScriptName);
		$count_pos = count($pos) - 2;
		if ($count_pos >= $pDept)
		{
			return Trim($pos[$pDept]);
		}
		else
		{
			return false;
		}
	}
	
	/**********************************************************************
	 * 문자열이 원하는 길이보다 클 경우 잘라줍니다.
	 * $a = "12345678901234567890";
	 * ex> StrCut_UTF_8($a, 10, "...");
	 * [결과] 1234567890...
	 *********************************************************************/
// 문자열 자르기(UTF-8용, StrCut2 function과 같이 사용함)
	function StrCut($pStr, $pLen, $pPad = "..")
	{
		
		$pStr = str_replace("\n", " ", $pStr);
		$pStr = str_replace("\r", "", $pStr);
		$pStr = str_replace("&nbsp;", " ", $pStr);
		$pStr = str_replace("  ", " ", $pStr);
		$pStr = str_replace("  ", " ", $pStr);
		
		if (trim($pStr) != "")
		{
			if (strlen($pStr) > $pLen)
			{
				return mb_strimwidth(trim($pStr), 0, $pLen, $pPad, "UTF-8");
			}
			else
			{
				return $pStr;
			}
		}
	}
	
	/**********************************************************************
	 * 페이징링크에서 URL상의 파라미터(REQUEST-QUERY-STRING)값을 유지함과 동시에
	 * 기존 파라미터에 포함되어 있는 "page=1" => "page=2"와 같이 기존의 파라미터의 값을 변경할때 사용
	 * ChangeQS(파라미터명, 치환을 원하는 값, [, 쿼리스트링의 시작문자가 '&'가 아닌 '?'와 같은 다른 문자를 원할경우])
	 * ex) ChangeQS("page", 2);
	 *********************************************************************/
	function ChangeQS($pName, $pValue, $pStartStr = null)
	{
		if (Trim($_SERVER['REQUEST_METHOD']) == "POST")
		{
			// POST 처리
		}
		else
		{
			// GET 처리
			$tmp_querystring = Trim($_SERVER['QUERY_STRING']);
			if (trim($tmp_querystring))
			{
				$tmp_querystring = "&" . str_replace("&amp;", "&", $tmp_querystring);
				if (strpos($tmp_querystring, "&" . $pName) !== false)
				{
					$start = strpos($tmp_querystring, $pName);
					$tmp_str = substr($tmp_querystring, $start, strlen($tmp_querystring));
					$len_q = strpos($tmp_str, "&");
					if ($len_q !== false)
					{
						$len_qvalue = $len_q;
						$str = substr($tmp_querystring, $start, $len_qvalue);
					}
					else
					{
						$str = substr($tmp_querystring, $start, strlen($tmp_querystring));
					}
					
					$QueryS = str_replace($str, $pName . "=" . $pValue, $tmp_querystring);
				}
				else
				{
					$QueryS = $tmp_querystring . "&" . $pName . "=" . $pValue;
				}
				
			}
			else
			{
				$QueryS = "&" . $pName . "=" . $pValue;
			}
		}
		
		if ($QueryS)
		{
			if ($pStartStr)
			{
				$QueryS = $pStartStr . substr($QueryS, 1, strlen($QueryS) - 1);
			}
			return $QueryS;
		}
	}
	
	/**********************************************************************
	 * input 구문에서 request값이 참일때 "checked"를 출력
	 * ex) <?php echo IsChecked(1, $pName); ?>
	 *********************************************************************/
	function IsChecked($pValue, $pValue2)
	{
		if ($pValue == $pValue2)
		{
			return "checked";
		}
	}
	
	/**********************************************************************
	 * input 구문에서 request_Array값이 참일때 "checked"를 출력 [배열용]
	 * ex) <?php echo IsChecked_Array(1, $pName); ?>
	 *********************************************************************/
	function IsChecked_Array($pValue, $pValue2)
	{
		$vResult = "";
		if (Is_Array($pValue2))
		{
			$tmp_cnt = count($pValue2);
			for ($i = 0; $i < $tmp_cnt; $i++)
			{
				if ($pValue2[$i] == $pValue)
				{
					$vResult = "checked";
				}
			}
			
			return $vResult;
		}
		elseif (strpos($pValue2, ",") !== false)
		{
			$tmp_ex = explode(",", $pValue2);
			$tmp_cnt = count($tmp_ex);
			for ($i = 0; $i < $tmp_cnt; $i++)
			{
				if ($tmp_ex[$i] != "")
				{
					if ($tmp_ex[$i] == $pValue)
					{
						$vResult = "checked";
					}
				}
				
			}
			return $vResult;
		}
		else
		{
			if ($pValue == $pValue2)
			{
				return "checked";
			}
		}
	}
	
	/**********************************************************************
	 * input 구문에서 request값이 참일때 "seleced"를 출력
	 * ex) <?php echo IsSelected(1, $pName); ?>
	 *********************************************************************/
	function IsSelected($pValue, $pValue2)
	{
		if ($pValue == $pValue2)
		{
			return "selected";
		}
	}
	
	/********************************************************************
	 * $pID에 속한 text를 업데이트합니다.
	 * ex> DivInnerHTML('cmt_layer_agree_11', '3')
	 ********************************************************************/
	function DivInnerHTML($pID, $pStr, $pWindow = null)
	{
		
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		
		if ($pWindow != null)
		{
			echo "  fm = $pWindow.document.getElementById('{$pID}');\n";
		}
		else
		{
			echo "  fm = document.getElementById('{$pID}');\n";
		}
		
		echo "  fm.innerHTML = \"{$pStr}\"; ";
		
		echo "//-->\n";
		echo "</script>\n";
		
	}
	
	/**********************************************************************
	 * input 구문에서 request값이 참일때 "seleced"를 출력
	 * ex) <?php echo IsSelected(1, $pName); ?>
	 *********************************************************************/
	function IsSelect_Class($pValue, $pValue2, $pClass)
	{
		if ($pValue == $pValue2)
		{
			return "class=\"$pClass\"";
		}
	}
	
	/********************************************************************
	 * iframe용 $pID에 속한 text를 업데이트합니다.
	 * ex> iframe_DivInnerHTML('cmt_layer_agree_11', '3')
	 ********************************************************************/
	function iframe_DivInnerHTML($pID, $pStr, $pWindow = null)
	{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=euc-kr\">\n";
		echo "</head>\n";
		echo "<body>\n";
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		
		if ($pWindow != null)
		{
			echo "  fm = $pWindow.document.getElementById('{$pID}');\n";
		}
		else
		{
			echo "  fm = document.getElementById('{$pID}');\n";
		}
		
		echo "  fm.innerHTML = \"{$pStr}\"; ";
		
		echo "//-->\n";
		echo "</script>\n";
		echo "</body>\n</html>\n";
	}
	
	/**********************************************************************
	 * 현재 있는 HOST주소와 이전페이지의 주소를 비교합니다.
	 * - $pReferer 인수가 $pHost인수보다 길이가 커야 합니다.
	 * ex) RefererCheck("http://www.abc.com", "http://www.abc.com/community/index.html");
	 *********************************************************************/
	function RefererCheck($pHost = "", $pReferer = "")
	{
		global $g_Referer;
		
		if ($pHost == "")
		{
			$pHost = _BASE_DOMAIN;
		}
		if ($pReferer == "")
		{
			$pReferer = $g_Referer;
		}
		if (strpos($pReferer, $pHost) === false)
		{
			Message2("올바른 접근 경로로 연결해주세요.", "/");
		};
	}
	
	/********************************************************************
	 *  <> 태그 제거
	 ********************************************************************/
	function stripHTML($pStr)
	{
		$vStr = strip_tags(trim($pStr));
		return trim($vStr);
	}
	
	/********************************************************************
	 * 데이터 교환(XML 등등)시 문자열을 ASCII/UNICODE로 디코딩하기
	 ********************************************************************/
	function Decode_ASCII_UNICODE($pStr)
	{
		$pStr = str_replace("&#126;", "~", $pStr);
		$pStr = str_replace("&#33;", "!", $pStr);
		$pStr = str_replace("&#64;", "@", $pStr);
		$pStr = str_replace("&#35;", "#", $pStr);
		$pStr = str_replace("&#36;", "$", $pStr);
		$pStr = str_replace("&#37;", "%", $pStr);
		$pStr = str_replace("&#94;", "^", $pStr);
		$pStr = str_replace("&#38;", "&", $pStr);
		$pStr = str_replace("&#42;", "*", $pStr);
		$pStr = str_replace("&#40;", "(", $pStr);
		$pStr = str_replace("&#41;", ")", $pStr);
		$pStr = str_replace("&#45;", "-", $pStr);
		$pStr = str_replace("&#43;", "+", $pStr);
		$pStr = str_replace("&#60;", "<", $pStr);
		$pStr = str_replace("&#62;", ">", $pStr);
		$pStr = str_replace("&#39;", "'", $pStr);
		$pStr = str_replace("&#34;", "\"", $pStr);
		$pStr = str_replace("&#60;", "<", $pStr);
		$pStr = str_replace("&#62;", ">", $pStr);
		
		$pStr = str_replace("&lt;", "<", $pStr);
		$pStr = str_replace("&gt;", ">", $pStr);
		$pStr = str_replace("&amp;", "&", $pStr);
		$pStr = str_replace("&nbsp;", " ", $pStr);
		$pStr = str_replace("&quot;", "\"", $pStr);
		
		return $pStr;
	}
	
	/********************************************************************
	 * 데이터 교환(XML 등등)시 문자열을 ASCII/UNICODE로 인코딩하기
	 ********************************************************************/
	function Encode_ASCII_UNICODE($pStr)
	{
		$pStr = str_replace("&", "&amp;", $pStr);
		$pStr = str_replace("~", "&#126;", $pStr);
		$pStr = str_replace("!", "&#33;", $pStr);
		$pStr = str_replace("@", "&#64;", $pStr);
		$pStr = str_replace("#", "&#35;", $pStr);
		$pStr = str_replace("$", "&#36;", $pStr);
		$pStr = str_replace("%", "&#37;", $pStr);
		$pStr = str_replace("^", "&#94;", $pStr);
		$pStr = str_replace("&", "&#38;", $pStr);
		$pStr = str_replace("*", "&#42;", $pStr);
		$pStr = str_replace("(", "&#40;", $pStr);
		$pStr = str_replace(")", "&#41;", $pStr);
		$pStr = str_replace("-", "&#45;", $pStr);
		$pStr = str_replace("+", "&#43;", $pStr);
		$pStr = str_replace("<", "&#60;", $pStr);
		$pStr = str_replace(">", "&#62;", $pStr);
		$pStr = str_replace("'", "&#39;", $pStr);
		$pStr = str_replace("\"", "&#34;", $pStr);
		$pStr = str_replace("<", "&#60;", $pStr);
		$pStr = str_replace(">", "&#62;", $pStr);
		
		$pStr = str_replace("<", "&lt;", $pStr);
		$pStr = str_replace(">", "&gt;", $pStr);
		$pStr = str_replace(" ", "&nbsp;", $pStr);
		$pStr = str_replace("\"", "&quot;", $pStr);
		
		return $pStr;
	}
	
	/********************************************************************
	 * 전달값 체크(개발시에만 사용함)
	 * ex> ValuesCheck()
	 ********************************************************************/
	function ValuesCheck()
	{
		
		$cnt = 1;
		while (list($key, $val) = each($_POST))
		{
			echo "<font color=blue>[post:$cnt]</font> " . $key . " = " . $val . "\n<br />";
			$cnt = $cnt + 1;
		}
		$cnt = 1;
		while (list($key, $val) = each($_GET))
		{
			echo "<font color=green>[get:$cnt]</font> " . $key . " = " . $val . "\n<br />";
			$cnt = $cnt + 1;
		}
		while (list($key, $val) = each($_COOKIE))
		{
			echo "<font color=red>[cookie:$cnt]</font> " . $key . " = " . $val . "\n<br />";
			$cnt = $cnt + 1;
		}
		while (list($key, $val) = each($_SESSION))
		{
			echo "<font color=red>[session:$cnt]</font> " . $key . " = " . $val . "\n<br />";
			$cnt = $cnt + 1;
		}
		
	}
	
	/********************************************************************
	 * 암호화 모듈 (암호화)
	 ********************************************************************/
	function Cryp_Encode($sText, $sCode)
	{
		if (trim($sText) != "")
		{
			$sText = "T" . $sText;
			$cntData = strlen($sText) - 1;
			$cntCode = strlen($sCode) - 1;
			$arrData = array();
			$arrCode = array();
			
			for ($i = 0; $cntData >= $i; $i++)
			{
				$arrData[$i] = $sText[$i];
			}
			
			for ($i = 0; $cntCode >= $i; $i++)
			{
				$arrCode[$i] = $sCode[$i];
			}
			
			$flag = 0;
			$strResult = "";
			
			for ($i = 0; $cntData >= $i; $i++)
			{
				$strResult = $strResult . (ord($arrData[$i]) ^ ord($arrCode[$flag])) . chr(8);
				if ($flag == $cntCode)
				{
					$flag = 0;
				}
				else
				{
					$flag++;
				}
			}
			return base64_encode($strResult);
		}
	}
	
	/********************************************************************
	 * 암호화 모듈 (복호화)
	 ********************************************************************/
	function Cryp_Decode($sText, $sCode)
	{
		if (trim($sText) != "")
		{
			$sText = base64_decode($sText);
			
			$arrData = split(chr(8), $sText);
			$arrCode = array();
			
			$cntData = count($arrData) - 2;
			$cntCode = strlen($sCode) - 1;
			
			for ($i = 0; $cntCode >= $i; $i++)
			{
				$arrCode[$i] = $sCode[$i];
			}
			
			$flag = 0;
			$strResult = "";
			
			for ($i = 0; $cntData >= $i; $i++)
			{
				$strResult = $strResult . chr((int)($arrData[$i]) ^ ord($arrCode[$flag]));
				if ($flag == $cntCode)
				{
					$flag = 0;
				}
				else
				{
					$flag++;
				}
			}
			$strResult = substr($strResult, 1, strlen($strResult) - 1);
			return $strResult;
		}
	}
	
	/**********************************************************************
	 * input 필터
	 * ex) ifilter("변수값", "변수타입", "최대길이(0일경우 제한없음)", "값이없을때 기본값(숫자형일 경우 기본값은 0")
	 *********************************************************************/
	function ifilter($pStr, $pType, $pLen = 0, $pDefault = NULL)
	{
		$result = "";
		$pPattern = array(
			"'<iframe[^>]*?>.*?</iframe>'si",
			"'<script[^>]*?>.*?</script>'si",
			"'<style[^>]*?>.*?</style>'si",
			"'<meta[^>]*?>'si",
			"/on([a-z]+)=/i",
			"/javascript:/i"
		);
		
		switch (strtoupper($pType))
		{
			case "NUMBER" :
				$result = trim($pStr);
				$result = strip_tags($result);
				$result = trim($result);
				$result = preg_replace("/[^0-9]*/s", "", $result);
				$result = trim($result, ' ');
				if (trim($result) == "")
				{
					if ($pDefault != NULL)
					{
						$result = $pDefault;
					}
					else
					{
						$result = 0;
					}
				}
				break;
			
			case "RAW" :
				$result = trim($pStr);
				$result = preg_replace($pPattern, "", $result);
				if (get_magic_quotes_gpc() != 1)
				{       // magic_quotes가 실행중이 아닐경우 ',"를 치환한다.
					$result = addslashes($result);
				}
				$result = str_ireplace("script", "ｓcript", $result);
				$result = str_ireplace("alert", "ａlert", $result);
				$result = str_ireplace("document.", "ｄocument.", $result);
				$result = str_ireplace("iframe ", "ｉframe ", $result);
				$result = str_ireplace("xss ", "ｘss ", $result);
				$result = str_ireplace("object ", "ｏbject ", $result);
				$result = str_ireplace("insert ", "ｉnsert ", $result);
				$result = str_ireplace("update ", "ｕpdate ", $result);
				$result = str_ireplace("delete ", "ｄelete ", $result);
				$result = str_ireplace("drop ", "ｄrop ", $result);
				$result = str_ireplace("create ", "ｃreate ", $result);
				$result = str_ireplace("exec ", "ｅxec ", $result);
				if (trim($result) == "")
				{
					$result = $pDefault;
				}
				break;
			
			case "ARRAY" :
				if (is_array($pStr))
				{
					$result = $pStr;
				}
				else
				{
					$result = "";
				}
				break;
			
			case "STRING" :
				$result = trim($pStr);
				$result = strip_tags($result);
				$result = trim($result);
				$result = preg_replace($pPattern, "", $result);
//          if(get_magic_quotes_gpc() != 1) {       // magic_quotes가 실행중이 아닐경우 ',"를 치환한다.
//              $result = str_ireplace("'", "&#39;", $result);
//              $result = str_ireplace("\"", "&#34;", $result);
//              $result = addslashes($result);
//          }
				$result = str_ireplace("script", "ｓcript", $result);
				$result = str_ireplace("alert", "ａlert", $result);
				$result = str_ireplace("document.", "ｄocument.", $result);
				$result = str_ireplace("iframe ", "ｉframe ", $result);
				$result = str_ireplace("xss ", "ｘss ", $result);
				$result = str_ireplace("object ", "ｏbject ", $result);
				$result = str_ireplace("embed", "ｅmbed ", $result);
				$result = str_ireplace("insert ", "ｉnsert ", $result);
				$result = str_ireplace("update ", "ｕpdate ", $result);
				$result = str_ireplace("delete ", "ｄelete ", $result);
				$result = str_ireplace("drop ", "ｄrop ", $result);
				$result = str_ireplace("create ", "ｃreate ", $result);
				$result = str_ireplace("exec ", "ｅxec ", $result);
				if (trim($result) == "")
				{
					$result = $pDefault;
				}
				break;
		}
		if ($pLen > 0)
		{
			$result = substr($result, 0, $pLen);
		}
		return $result;
	}
	
	function fnTransTextRead($p_txt)
	{
		if ((!$p_txt) or (trim($p_txt) == ""))
		{
			$f_txt = "";
		}
		else
		{
			$f_txt = $p_txt;
			$f_txt = str_replace("&", "&amp;", $f_txt);
			$f_txt = str_replace("<", "&lt;", $f_txt);
			$f_txt = str_replace(">", "&gt;", $f_txt);
			$f_txt = str_replace("\"", "&quot;", $f_txt);
			$f_txt = str_replace("\n", "<br>", $f_txt);
		}
		return $f_txt;
	}
	
	function fnTransHtmlRead($p_txt)
	{
		if ((!$p_txt) or (trim($p_txt) == ""))
		{
			$f_txt = "";
		}
		else
		{
			$f_txt = $p_txt;
		}
		return $f_txt;
	}
	
	function fnInputTextRead($p_txt)
	{
		if ((!$p_txt) or (trim($p_txt) == ""))
		{
			$f_txt = "";
		}
		else
		{
			$f_txt = $p_txt;
			$f_txt = str_replace("\"", "&quot;", $f_txt);
		}
		return $f_txt;
	}
	
	/********************************************************************
	 * 로그인 체크
	 ********************************************************************/
	function CheckLogin($type = "")
	{
		global $logChk;
		
		$result = $logChk;
		
		if ($result != 1)
		{
			if ($type == "noalert")
			{
				Message2("", "/member/login.sm");
			}
			else
			{
				Message2("로그인해주세요.", "/member/login.sm");
			}
		}
		
		
	}
	
	/**********************************************************************
	 * 로그인 URL
	 * ex) LoginURL("http://www.abc.com");
	 *********************************************************************/
	function LoginURL($pURL)
	{
		return "/cs/login.htm?rurl=" . urlencode($pURL);
	}
	
	/********************************************************************
	 * 알림창을 띄우고 목적지 경로로 이동합니다.
	 * ex> Message("잘못된 접근입니다.");
	 *     Message("확인되었습니다.", "http://www.abc.com/index.html");
	 ********************************************************************/
	function Message($pMessage, $pURL = "", $pTarget = null)
	{
		
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
		echo "</head>\n";
		echo "<body>\n";
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		if ($pMessage)
		{
			echo "alert(' {$pMessage}      ');\n";
		}
		if ($pTarget)
		{
			$vTarget = $pTarget . ".";
		}
		else
		{
			$vTarget = "";
		}
		if ($pURL == null)
		{
			echo $vTarget . "history.back();\n";
		}
		elseif ($pURL == "stop")
		{
			// 그냥 멈춤
		}
		elseif ($pURL == "close")
		{
			echo "self.close();\n";
		}
		elseif ($pURL == "reload")
		{
			echo $vTarget . "location.reload(true);\n";
		}
		else
		{
			echo $vTarget . "location.href = '$pURL';\n";
		}
		echo "//-->\n";
		echo "</script>\n";
		echo "</body>\n</html>\n";
		exit;
		
	}
	
	/********************************************************************
	 * 알림창을 띄우고 목적지 경로로 이동합니다.
	 * ex> Message2("잘못된 접근입니다.");
	 *     Message2("확인되었습니다.", "http://www.abc.com/index.html");
	 ********************************************************************/
	function Message2($pMessage, $pURL = "", $pTarget = "_top")
	{
		
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
		echo "</head>\n";
		echo "<body>\n";
		
		if ($pURL == null)
		{
		
		}
		elseif ($pURL == "stop")
		{
		
		}
		elseif ($pURL == "close")
		{
		
		}
		elseif ($pURL == "reload")
		{
		
		}
		else
		{
			echo "<form name=\"form_location\" action=\"" . $pURL . "\" method=\"get\" target=\"" . $pTarget . "\"></form>";
		}
		
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		if ($pMessage)
		{
			echo "alert(' {$pMessage}      ');\n";
		}
		if ($pTarget)
		{
			$vTarget = $pTarget . ".";
		}
		else
		{
			$vTarget = "";
		}
		if ($pURL == null)
		{
			echo $vTarget . "history.back();\n";
		}
		elseif ($pURL == "stop")
		{
			// 그냥 멈춤
		}
		elseif ($pURL == "close")
		{
			echo "self.close();\n";
		}
		elseif ($pURL == "reload")
		{
			echo $vTarget . "location.reload(true);\n";
		}
		else
		{
			echo "document.form_location.submit();\n";
		}
		echo "//-->\n";
		echo "</script>\n";
		echo "</body>\n</html>\n";
		exit;
		
	}
	
	function Message_Recommend($pMessage, $pRecommendName, $pRecommendCount, $pCommon = 0)
	{
		
		global $g_RefererURL;
		
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
		echo "</head>\n";
		echo "<body>\n";
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		if ($pCommon == 1)
		{
			echo "document.domain = 'www2.happyleports.com'\n";
		}
		
		echo "parent.document.getElementById('{$pRecommendName}').innerHTML = '{$pRecommendCount}';\n";
		
		// 게시판 view 상단용
		if (strpos($g_RefererURL, "magazine") == true || strpos($g_RefererURL, "news") == true || strpos($g_RefererURL, "board") == true)
		{
			echo "parent.document.getElementById('recommend-count2').innerHTML = '{$pRecommendCount}';\n";
		}
		if ($pMessage)
		{
			echo "alert(' {$pMessage}      ');\n";
		}
		echo "//-->\n";
		echo "</script>\n";
		echo "</body>\n</html>\n";
		exit;
		
	}
	
	/********************************************************************
	 * 알림창을 띄우고 목적지 경로로 이동합니다.
	 * ex> Message("잘못된 접근입니다.");
	 *     Message("확인되었습니다.", "http://www.abc.com/index.html");
	 ********************************************************************/
	function Confirm($pMessage, $pURL = "", $pURL2 = "", $pTarget = null)
	{
		
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
		echo "</head>\n";
		echo "<body>\n";
		echo "<script type=\"text/javascript\">\n";
		echo "<!--\n";
		if ($pTarget)
		{
			$vTarget = $pTarget . ".";
		}
		else
		{
			$vTarget = "";
		}
		if ($pMessage)
		{
			echo "if(confirm(' {$pMessage}      ')) { {$vTarget}location.href = '{$pURL}'; } else { {$vTarget}location.href = '{$pURL2}'; };\n";
		}
		echo "//-->\n";
		echo "</script>\n";
		echo "</body>\n</html>\n";
		exit;
		
	}
	
	/**********************************************************************
	 * 페이지를 이동합니다.
	 * ex) MovePage("./");
	 *********************************************************************/
	function MovePage($pURL, $pTarget = null)
	{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\n";
		echo "<html>\n";
		echo "<head>\n";
		echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
		echo "</head>\n";
		echo "<body>\n";
		if ($pTarget)
		{
			$vTarget = $pTarget . ".";
		}
		else
		{
			$vTarget = "";
		}
		echo "<script type=\"text/javascript\">" . $vTarget . "location.href='$pURL';</script>\n";
		echo "</body>\n</html>\n";
		exit;
	}
	
	/********************************************************************
	 * 페이지 정상유무 체크(return 200 이면 정상)
	 ********************************************************************/
// set cookie (암호화 처리)
	function SET_CK($pName, $pValue, $pExpiredays = 0, $pCryp = 1)
	{
		global $g_BaseAccount, $g_BaseDomain;
		if ($pCryp == 1)
		{
			$pValue2 = Cryp_Encode($pValue, $g_BaseAccount);
		}
		else
		{
			$pValue2 = $pValue;
		}
		if ($pExpiredays > 0)
		{
			$pExpireTime = time() + ((60 * 60 * 24) * $pExpiredays);
		}
		else
		{
			$pExpireTime = 0;
		}
		setcookie($pName, $pValue2, $pExpireTime, "/", $g_BaseDomain);
	}

// get cookie (복호화 처리)
	function GET_CK($pName, $pCryp = 1)
	{
		global $g_BaseAccount;
		$pValue = $_COOKIE[$pName];
		if ($pCryp == 1)
		{
			$result = Cryp_Decode($pValue, $g_BaseAccount);
		}
		else
		{
			$result = $pValue;
		}
		return $result;
	}

//////////////////////////////////////////////////////
// Get the last day of the month
	function LastDayOfMonth($pYear = '', $pMonth = '')
	{
		if (empty($pYear))
		{
			$pYear = date('Y');
		}
		if (empty($pMonth))
		{
			$pMonth = date('m');
		}
		
		$result = strtotime("{$pYear}-{$pMonth}-01");
		$result = strtotime('-1 second', strtotime('+1 month', $result));
		return date('d', $result);
	}

//////////////////////////////////////////////////////
// MicroTimes
	function microtime_float()
	{
		list($usec, $sec) = explode(" ", microtime());
		return (round((float)$usec * 100, 0));
	}
	
	
	function FileCache_TCount($pFuncName, $pFileName, $pTime = 5)
	{
		global $g_GenDir;
		
		$Result = "";
		$FileName = $pFileName;
		$Cache_Check = 0;
		
		if (file_exists($g_GenDir . "/" . $FileName))
		{
			$mtime = filemtime($g_GenDir . "/" . $FileName);
			if ($mtime > (time() - 60 * $pTime))
			{
				// 유효시간 범위
				$Result = FileRead($g_GenDir, $FileName);
			}
			else
			{
				// 유효시간 초과
				$Cache_Check = 1;
			}
		}
		else
		{
			$Cache_Check = 1;
		}
		
		if ($Cache_Check == 1)
		{
			
			$Result = $pFuncName();
			MakeGenFile($g_GenDir, $FileName, $Result);
			
		}
		return $Result;
		
	}
	
	function byteConvert($bytes)
	{
		$s = array('B', 'Kb', 'MB', 'GB', 'TB', 'PB');
		$e = floor(log($bytes) / log(1024));
		
		return sprintf('%.2f ' . $s[$e], ($bytes / pow(1024, floor($e))));
	}
	
	function TipText($pTitle, $pText)
	{
		return " onmouseover=\"Tip('{$pText}', DELAY, 0, PADDING, 5, TITLE, '{$pTitle}', TITLEPADDING, 5);\" onmouseout=\"UnTip();\" style=\"cursor:pointer;\"";
	}
	
	function WeekDayName($pWeekday)
	{
		$yoil = array('일', '월', '화', '수', '목', '금', '토');
		
		return $yoil[$pWeekday];
	}
	
	/**********************************************************************
	 * SMS 발송
	 * ex) SMSSender("받는사람번호", "메세지내용", "[태그내용] <= 태그내용, 생략가능")
	 *********************************************************************/
	function SMSSender($pReceiveNum, $pMSG, $pMSGTitle = '')
	{
		
		global $g_BaseAccount, $g_UserIP, $g_Location, $userid;
		
		include_once "/home/" . $g_BaseAccount . "/public_html/@inc/sms.config.php";
		include_once "/home/" . $g_BaseAccount . "/public_html/@inc/Snoopy.class.php";
		
		$snoopy = new Snoopy;
		$result = 0;
		
		if (trim($pMSG) != "")
		{
			if ($pMSGTitle != "")
			{
				$pMSG = "[{$pMSGTitle}]\n" . $pMSG;
			}
			$OPENURL = $PROCURL . "&rphone=" . str_replace("-", "", $pReceiveNum) . "&msg=" . urlencode(iconv("utf-8", "euc-kr", $pMSG));
			if ($snoopy->fetch($OPENURL))
			{
				if ($snoopy->results == "OK")
				{
					$result = 1;
				}
				
				// DB logs
				$nowtime = time();
				$sql_logs = " insert into USER_LOG_SMS (user_id, sendnum, receivenum, msg, userip, location, reg_date) values ('{$userid}', '{$SPHONE}', '" . str_replace("-", "", $pReceiveNum) . "', '{$pMSG}', '{$g_UserIP}', '{$g_Location}', '{$nowtime}'); ";
				DBQuery($sql_logs);
			}
		}
		return $result;
	}


// 기준 도메인 추출(쿠키, 세션 사용시 이용)
	function getBaseDomain($pBaseDomain)
	{
		
		if (!$pBaseDomain)
		{
			Message("[Error] g_BaseDomain 설정을 확인하세요!");
		}
		$result_tmp = explode(".", $pBaseDomain);
		$cnt = count($result_tmp);
		if ($cnt == 3)
		{
			$result = $result_tmp[1] . "." . $result_tmp[2];
		}
		elseif ($cnt == 2)
		{
			$result = $result_tmp[0] . "." . $result_tmp[1];
		}
		else
		{
			Message("[Error] g_BaseDomain 설정을 확인하세요!");
		}
		return $result;
	}
	
	/*
	function sendmail($fromName, $fromEmail, $toName, $toEmail, $subject, $body) {
		$mail = "";
	
		$encoded_subject = "=?UTF-8?B?".base64_encode($subject)."?=\n";
		$to = "\"=?UTF-8?B?".base64_encode($toName)."?=\" <".$toEmail.">" ;
		$from= "\"=?UTF-8?B?".base64_encode($fromName)."?=\" <".$fromEmail.">" ;
		$headers="MIME-Version: 1.0\n".
						"Content-Type: text/html; charset=UTF-8; format=flowed\n".
						"To: ". $to ."\n".
						"From: ".$from."\n".
						"Content-Transfer-Encoding: 8bit\n";
		$mail = mail($to, $encoded_subject, $body , $headers);
		return $mail;
	}
	*/
	
	function createID()
	{
		$pid = inc_UtilFunc . phpdate("YmdHis", time()) . rand(100, 999);
		
		return $pid;
	}
	
	function getUnixtime($pDateStr, $pSepStr)
	{
		
		list($pDate1, $pDate2, $pDate3) = explode($pSepStr, $pDateStr);
		
		if ($pDateStr)
		{
			$pDateStr = mktime("0", "0", "0", $pDate2, $pDate3, $pDate1);
		}
		
		return $pDateStr;
	}

// 변수값 확인 function - 개발용
	function RW($pValueName)
	{
		global ${$pValueName};
		echo "{$pValueName}: " . ${$pValueName} . "<br />\n";
	}
	
	// 파일사이즈 구하기
	function human_file_size($size)
	{
		if ($size == 0)
		{
			return ("0 MB");
		}
		$filesizename = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");
		return inc_UtilFunc . phpround($size / pow(1024, ($i = floor(log($size, 1024)))), 2) . $filesizename[$i];
	}
	
	function returnFalse($res, $statusCode, $codeNo, $_msg, $msg = null)
	{
		if ($res == null)
		{
			global $json_content;
			
			if (!$msg)
			{
				$msg = $codeNo;
			}
			
			print (json_encode($json_content = array('code' => $statusCode, 'msg' => $msg, '_msg' => $_msg)));
			error_log("\nAPI_ERROR: code: {$json_content['code']}, _msg: {$json_content['_msg']}");
			exit();
		}
	}
	
	function isToken()
	{
		$authyn = false;
		
		if (isset($_SERVER["HTTP_AUTHORIZATION"]))
		{
			$authStr = $_SERVER["HTTP_AUTHORIZATION"];
			$jwttoken = str_replace("Bearer ", "", $authStr);
			$authyn = isExpToken($jwttoken);
		}
		return $authyn;
	}