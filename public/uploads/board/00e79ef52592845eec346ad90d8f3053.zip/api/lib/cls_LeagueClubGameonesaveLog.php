<?php
	
	class LeagueClubGameonesaveLog
	{
		private  $tableName = "league_club_gameonesave_log"; 		    # 테이블 명
		
		/* 생성자 함수 */
		public function __construct()
		{
			global $db;
			
			$this->db = $db;
		}
		
		public function getListCount()
		{
			$and = $this->where;
			
			$sql = "
				SELECT count(*) AS CNT
				   FROM {$this->tableName}
				 WHERE 1 = 1
				      {$and}
			";
			
			$data = $this->db->getRecord($sql);
			
			return $data["CNT"];
		}
		
		public function getList()
		{
			$and = $this->where;
			$orderby = "ORDER BY reg_date DESC";
			
			$sql = "
				SELECT gslog_seq, lig_idx, REPLACE(trim(lig_name), '\n\t\t\t\t\t\t\t', '') AS lig_name, club_idx, REPLACE(trim(club_name), '\n\t\t\t\t\t\t\t', '') AS club_name, item, user_id, user_name, status, amount, quantity, season, ord_no, pay_method, reg_date, description, receiver_name, receiver_number, mod_date, gs_flag
				   FROM {$this->tableName}
				 WHERE 1 = 1
				      {$and}
				{$orderby}
				LIMIT {$this->pageInfo->first}, {$this->pageInfo->numPerPage}
			";
			
			return $this->db->getRecords($sql);
		}
		
		public function getPager($pagesize, $page)
		{
			$pm = new PageManager($pagesize, 10, $this->getListCount(), $page);
			$pm->calcPage();
			
			$this->pageInfo = $pm;
			
			return $this->pageInfo;
		}
	}