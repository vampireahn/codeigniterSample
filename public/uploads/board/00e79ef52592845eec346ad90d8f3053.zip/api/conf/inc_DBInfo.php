<?
	$db_info["host"] = "218.145.31.111";
	$db_info["user"] = "gameone_user";
	$db_info["passwd"] = "baseballdb&(*)";
	$db_info["dbname"] = "gameone_allnew";
?>