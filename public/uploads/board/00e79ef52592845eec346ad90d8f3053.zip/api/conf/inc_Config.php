<?
	/**
	 * ------------- -----------------------------------------------------------
	 * PGM name    : /conf/inc_Config.cnb
	 * ------------- -----------------------------------------------------------
	 * PGM comment : global환경 설정 파일. 프로그램 전역에 걸쳐 사용되는 정보와
	 * 커스터마이징 해야 하는 함수 루틴들
	 * ------------- -----------------------------------------------------------
	 * PGM history :   변경일자         변경자            변경내용
	 * ------------- ------------ ------------ -----------------------------------
	 *                          2012.02.29   vampireahn   최초 개발
	 * ------------- ------------ ------------ -----------------------------------
	 **/
	
	const _VER = "1.0";   // 사이트 라이브러리 버젼
	
	date_default_timezone_set('Asia/Seoul');          // 기본 시간대 설정
	header('Content-type: text/html; charset=UTF-8'); // Charset 설정
	
	const _STATS_LOGOUT_TIME = 300;
	
	const _BASE_ACCOUNT = "/free/home/dev_api/html"; // 기준계정
	const _BASE_DOMAIN = "dev-api.gameone.kr/"; // 기준도메인
	define("_HOME_URL", "http://" . $_SERVER["SERVER_NAME"]);
	
	define("_SPATH_ROOT", $_SERVER['DOCUMENT_ROOT'] . "/api/"); // 소스 루트 디렉토리
//	const _SPATH_DATA = "/WebService/" . _BASE_ACCOUNT . "/data/"; // 파일 업로드 디렉토리
	const _SPATH_DATA = _BASE_ACCOUNT . "/WebService/data/"; // 파일 업로드 디렉토리
	const _SPATH_CONFIG = _SPATH_ROOT . "conf/"; // 소스 라이브러리 디렉토리
	const _SPATH_LIB = _SPATH_ROOT . "lib/"; // 소스 라이브러리 디렉토리
	const _SPATH_MODEL = _SPATH_ROOT . "model/"; // 소스 모델 디렉토리
	const _SPATH_SKIN = _SPATH_ROOT . "skin/"; // 소스 스킨 디렉토리
	const _SPATH_FILE = "";// 업로드 디렉토리(절대경로)
	
	const _WPATH_ROOT = "/"; // 웹 루트 디렉토리
	const _WPATH_LIB = _WPATH_ROOT . "lib/"; // 웹 라이브러리 디렉토리
	const _WPATH_MODEL = _WPATH_ROOT . "model/"; // 웹 스킨 디렉토리
	const _WPATH_SKIN = _WPATH_ROOT . "skin/"; // 웹 스킨 디렉토리
	const _WPATH_JS = _WPATH_SKIN . "js/"; // 웹 자바스크립트 디렉토리
	const _WPATH_CSS = _WPATH_SKIN . "css/"; // 웹 자바스크립트 디렉토리
	const _WPATH_JW = _WPATH_SKIN . "jwplayer/"; // 웹 자바스크립트 디렉토리
	const _WPATH_IMG = _WPATH_SKIN . "images/"; // 웹 자바스크립트 디렉토리
	const _WPATH_EDITOR = _WPATH_ROOT . "Spac_Editor/"; // 웹 에디터 디렉토리
	
	const _TITLE_MAIN = ""; // 메인 타이틀 (브라우저 상단 타이틀바 제목)
	const _MAIL_COMPANY = ""; // 사이트 주소
	const _MAIL_MANAGER = ""; // 회사 메일 주소
	
	/* 상단 및 하단 include 파일 정의 여러종류의 인클루드 파일이 있을경우 종류별로 여기에 상수 정의하여 사용한다.*/
	const _INCLUDE_HEADER = _SPATH_SKIN . "include/header.cnb";
	const _INCLUDE_FOOTER = _SPATH_SKIN . "include/footer.cnb";
	const _INCLUDE_PAGER = _SPATH_SKIN . "include/pager.cnb";
	const _INCLUDE_TOP = _SPATH_SKIN . "include/top.cnb";
	const _INCLUDE_BOTTOM = _SPATH_SKIN . "include/bottom.cnb";
	const _INCLUDE_LEFT_RE_MENU = _SPATH_ROOT . "repo/leftMenu.cnb";
	const _INCLUDE_LEFT_RC_MENU = _SPATH_ROOT . "recom/leftMenu.cnb";
	
	/* session start */
//	session_save_path("/WebService/" . _BASE_ACCOUNT . "/session");
//	session_set_cookie_params(0, "/", "." . $_SERVER["SERVER_NAME"]);
//	ini_set("session.cookie_domain", "." . $_SERVER["SERVER_NAME"]);
//	session_start();
	
	if (!get_magic_quotes_gpc())
	{
		function addslashes_deep($value)
		{
			return $value = is_array($value) ? array_map('addslashes_deep', $value) : htmlspecialchars($value, ENT_QUOTES);
		}
		
		$_POST = array_map('addslashes_deep', $_POST);
		$_GET = array_map('addslashes_deep', $_GET);
		$_REQUEST = array_map('addslashes_deep', $_REQUEST);
		$_COOKIE = array_map('addslashes_deep', $_COOKIE);
	}
	
	/* Common library include : 모든 페이지에 공통적으로 포함되는 모듈을 include한다. */
	function __autoload($class)
	{
		foreach (array("", "board/", "member/", "basic/") as $path)
		{
			$path_file = _SPATH_LIB . $path . "cls_" . $class . ".php";
			if (is_file($path_file))
			{
				$class_file = $path_file;
				break;
			}
		}
		require_once($class_file);
	}
	
	require_once(_SPATH_LIB . "inc_UtilFunc.php");
	require_once(_SPATH_CONFIG . "inc_DBInfo.php");
	$db = new DBManager();
	
	if (isset($_SESSION["logChk"]))
	{
		$logChk = $_SESSION["logChk"];
		
		if ($logChk == 1)
		{
			$userID = trim($_SESSION["userID"]);
			$userNickName = trim($_SESSION["USER_NICK_NAME"]);
			$userLevel = trim($_SESSION["userLevel"]);
			if ($userID != "")
			{
				// ture
			}
			else
			{
				// false
				$logChk = 0;
				$userID = "";
				$userLevel = 0;
			}
		}
	}
	
	/* URL depth별 경로 */
	$g_ScriptName1 = ScriptName(1);
	$g_ScriptName2 = ScriptName(2);
	$g_ScriptName3 = ScriptName(3);
	
	$g_Referer = getenv("HTTP_REFERER");   //현재 페이지에 이동하기 앞에 사용자 에이전트가 참조하고 있었던 페이지
	$g_Host = getenv("HTTP_HOST");      //현재 페이지에 액세스하고 있는 호스트명
	$g_Filename = getenv("SCRIPT_NAME");    //
	$g_UserAgent = getenv("HTTP_USER_AGENT");//스크립트 실행 요청한 클라이언트의 브라우저 종류 및 버전
	$g_UserIP = getenv("REMOTE_ADDR");    //스크립트 실행 요청한 클라이언트의 IP