<?php
	/** Include files */
	include_once($_SERVER ["DOCUMENT_ROOT"] . "/api/conf/inc_Config.php"); // required
	
	$rawBody = file_get_contents("php://input"); // 본문을 불러옴
	$requestData = json_decode($rawBody, true); // 데이터를 변수에 넣고
	
	$res["id"] = $requestData["id"];
	$res["pass"] = $requestData["pass"];
	
	$jsonContent = array(
		"code" => 200,
		"_msg" => "OK",
		"RESULT" => $res
	);
	
	header('Content-Type: application/json');
	print json_encode($jsonContent);