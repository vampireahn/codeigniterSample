<?php
	/** Include files */
	include_once($_SERVER ["DOCUMENT_ROOT"] . "/api/conf/inc_Config.php"); // required
	
//	$str = base64_decode($_REQUEST['imagefile']);
//	$tmpfname = tempnam("/tmp", "test_");
//	$handle = fopen($tmpfname, "wb");
//	fwrite($handle, $str);
//	fclose($handle);
	
	$rawBody = file_get_contents("php://input"); // 본문을 불러옴
	$requestData = json_decode($rawBody, true); // 데이터를 변수에 넣고
//	var_dump($requestData);
	
	$str = base64_decode($requestData['imagefile']);
	$tmpfname = tempnam("/tmp", "test_");
	$handle = fopen($tmpfname, "wb");
	fwrite($handle, $str);
	fclose($handle);
	
	$fileName = $requestData["fileName"];
	$folder = $requestData["folder"];
	$thumbYN = $requestData["thumbYN"];
	
//	$fileName = $_REQUEST["fileName"];
//	$folder = ifilter($_REQUEST["folder"], "string");
//	$thumbYN = ifilter($_REQUEST["thumbYN"], "string");
	
	$server_host = "218.145.31.86";  // 원격서버의 ip주소
	
	$server_id= "dev_api";              // 원격서버의 서버id
	$server_pw = "gameone#api";   // 원격서버의 서버password
	
	if ($fileName != "")
	{
		$fType = end(explode(".", $fileName));

		if (strtolower($fType) == "jpg" || strtolower($fType) == "gif" || strtolower($fType) == "png" || strtolower($fType) == "jpeg")
		{
			$uploadFile =  md5(date("YmdHis") . $fileName) . "." . $fType;
			$server_path = _SPATH_DATA . $uploadFile;
			$result = copy($tmpfname, $server_path);

			$exif = @exif_read_data($server_path);

			if($exif['Orientation'] == 8)
			{
				$tumb = new Image($server_path);

				if ($folder == "userinfo")
				{
					$tumb->height(100);
				}
				else if($folder == "cover")
				{
					$tumb->height(990);
				}
				else if ($folder == "board")
				{
					$tumb->height(665);
				}

				$tumb -> save();
			}
			else
			{
				$tumb = new Image($server_path);

				if ($folder == "userinfo")
				{
					$tumb->width(100);
				}
				else if($folder == "cover")
				{
					$tumb->width(990);
				}
				else if ($folder == "board")
				{
					$tumb->width(665);
				}

				$tumb -> save();
			}

			if($thumbYN == "Y")
			{
				$server_path_thum = _SPATH_DATA . "thum_" . $uploadFile;
//			    echo  $tmpfname ." | " . $server_path_thum;
				$result = copy($tmpfname, $server_path_thum);

				if($exif['Orientation'] == 8)
				{
					$tumb = new Image($server_path_thum);
					$tumb -> height(320);
					$tumb -> save();
				}
				else
				{
					$tumb = new Image($server_path_thum);
					$tumb -> width(320);
					$tumb -> save();
				}
			}

//			@unlink($tmpfname);

			if(!($fc = ftp_connect($server_host)))
			{
				returnFalse(null, 500, "BOARD_2040", "원격서버 연결 실패");
			}

			//원격서버에 로그인한다.
			$ftpRes = ftp_login($fc, $server_id, $server_pw);
			// 패스티브 모드 사용
			ftp_pasv($fc, true);

			if(!$ftpRes)
			{
				returnFalse(null, 500, "BOARD_2050", "원격서버 로그인 실패");
			}

			//업로드할 폴더 지정
			$server_dir = "/html/WebService/data/" . $folder;

			if(ftp_chdir($fc, $server_dir))
			{ //업로드할 폴더로 이동한다.
				if(!ftp_put($fc, $uploadFile, $server_path, FTP_BINARY))
				{
					returnFalse(null, 500, "BOARD_2070", "FTP 파일 업로드 실패");
				}

				if($thumbYN == "Y")
				{
					if(!ftp_put($fc, "thum_" . $uploadFile, $server_path_thum, FTP_BINARY))
					{
						returnFalse(null, 500, "BOARD_2070", "FTP 파일 업로드 실패");
					}
				}

			}
			else
			{
				returnFalse(null, 500, "BOARD_2060", "FTP 파일 업로드 경로 불가(경로 확인)");
			}

			// FTP를 닫는다
			ftp_close($fc);
			@unlink($server_path);
			@unlink($server_path_thum);
		}
		else
		{
			returnFalse(null, 500, "BOARD_2090", "이미지 파일(jpg, gif, png)만 가능");
		}

	}

	$res["IMAGE_FILE"] = $uploadFile;

	if ($thumbYN == "Y")
	{
		$res["THUM_IMAGE_FILE"] = "thum_" . $uploadFile;
	}

	$jsonContent = array(
		"code" => 200,
		"_msg" => "OK",
		"RESULT" => $res
	);
	
	header('Content-Type: application/json');
	print json_encode($jsonContent);