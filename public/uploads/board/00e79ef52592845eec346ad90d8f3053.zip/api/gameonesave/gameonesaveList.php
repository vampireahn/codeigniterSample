<?php
	/**
	 * Parameter Object
	 */
	if (!empty($requestData))
	{
		$page = ifilter($requestData["page"], "number");
		$pageSize = ifilter((!$requestData["pageSize"] ? 10 : $requestData["pageSize"]), "number");
		$beginDate = ifilter($requestData["begin_date"], "string");
		$endDate = ifilter($requestData["end_date"], "string");
		$status = ifilter($requestData["status"], "string");
		$gsFlag = ifilter($requestData["gs_flag"], "string");
	}
	
	if ($beginDate == "" && $endDate == "")
	{
		$leagueClubGameonesaveLog->where .= " AND SUBSTRING(reg_date, 1, 10) >= '2022-11-01'";
		$leagueClubGameonesaveLog->where .= " AND SUBSTRING(reg_date, 1, 10) <= '" . date("Y-m-d") . "'";
	}
	else
	{
		$leagueClubGameonesaveLog->where .= " AND SUBSTRING(reg_date, 1, 10) >= '{$beginDate}'";
		$leagueClubGameonesaveLog->where .= " AND SUBSTRING(reg_date, 1, 10) <= '{$endDate}'";
	}
	
	if ($status == "")
	{
		$leagueClubGameonesaveLog->where .= " AND status in ('a_give', 'a_take')";
	}
	
	if ($gsFlag != "")
	{
		$leagueClubGameonesaveLog->where .= " AND gs_flag = '{$gsFlag}'";
	}
	
	$totCNT = $leagueClubGameonesaveLog->getListCount();
	
	// 페이징
	$totPager = $leagueClubGameonesaveLog->getPager($pageSize, $page);
	
	$data = $leagueClubGameonesaveLog->getList();
	
	$pager = $leagueClubGameonesaveLog -> pageInfo;
	$topIdx = $pager -> topIdx;
	
	$boardRes['TOTAL_COUNT'] = $totCNT;
	$boardRes['TOTAL_PAGE'] = $totPager->totalPage;
	
	
	$tmpData = array();
	foreach ((array)$data as $key => $value)
	{
		$tmpData[$key]["gslog_seq"] = (int)$value["gslog_seq"];
		$tmpData[$key]["lig_idx"] = ($value["lig_idx"] > 0 ? (int)$value["lig_idx"] : "");
		$tmpData[$key]["lig_name"] = $value["lig_name"];
		$tmpData[$key]["club_idx"] = ($value["club_idx"] > 0 ? (int)$value["club_idx"] : "");
		$tmpData[$key]["club_name"] = $value["club_name"];
		$tmpData[$key]["item"] = $value["item"];
		$tmpData[$key]["user_id"] = $value["user_id"];
		$tmpData[$key]["user_name"] = $value["user_name"];
		$tmpData[$key]["status"] = $value["status"];
		$tmpData[$key]["amount"] = (int)$value["amount"];
		$tmpData[$key]["quantity"] = (int)$value["quantity"];
		$tmpData[$key]["season"] = $value["season"];
		$tmpData[$key]["ord_no"] = $value["ord_no"];
		$tmpData[$key]["pay_method"] = $value["pay_method"];
		$tmpData[$key]["reg_date"] = $value["reg_date"];
		$tmpData[$key]["description"] = $value["description"];
		$tmpData[$key]["receiver_name"] = $value["receiver_name"];
		$tmpData[$key]["receiver_number"] = $value["receiver_number"];
		$tmpData[$key]["mod_date"] = $value["mod_date"];
		$tmpData[$key]["gs_flag"] = $value["gs_flag"];
	}
	$boardRes["BOARD_DATA"] = $tmpData;
	
	$jsonContent = array(
		'code' => '200',
		'msg' => 'OK',
		'RESULT' => $boardRes
	);
	
	header('Content-Type: application/json; charset=UTF-8');
	
	print json_encode($jsonContent);