<?php
	/** Include files */
	include_once($_SERVER ["DOCUMENT_ROOT"] . "/api/conf/inc_Config.php"); // required
	$headers = apache_request_headers();
	$authorization = trim(str_replace("Bearer", "", $headers["Authorization"]));
	
	$rawBody = file_get_contents("php://input"); // 본문을 불러옴
	$requestData = json_decode($rawBody, true); // 데이터를 변수에 넣고
	
	$type = $requestData['type'];
	$lig_idx = $requestData['lig_idx'];
	
	if ($type == "")
	{
		returnFalse(null, 400, 400, "type parameter값 없음.");
	}
	
	$leagueClubGameonesaveLog = new LeagueClubGameonesaveLog();
	
	if ($type == "list")
	{
		include_once "gameonesaveList.php";
	}
	
	