<?php
	
	class Board extends Curl
	{
		/** 생성자 함수 */
		public function __construct()
		{
			parent::__construct("");
		}
		
		public function getCheck($data)
		{
			$this->url = "http://{$this -> apiHostname}/api/imgupload/check.php";
			
			return $this->getBody($data);
		}
	}