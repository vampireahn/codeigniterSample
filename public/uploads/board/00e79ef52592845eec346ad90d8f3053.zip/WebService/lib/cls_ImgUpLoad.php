<?php
	
	class ImgUpLoad extends Curl
	{
		/** 생성자 함수 */
		public function __construct()
		{
			parent::__construct("");
		}
		
		/**
		 * @param $file - temp파일
		 * @param $fileType - fileType
		 * @param $fileName - fileName
		 * @return bool|string
		 */
		public function setImgUpload($folder, $file, $fileName, $thumbYN = null)
		{
			$handle = fopen($file, "r");
			$data = base64_encode(fread($handle, filesize($file)));
			
			// $data is file data
			if ($thumbYN == "Y")
			{
				$post = array('folder' => $folder, 'imagefile' => $data, 'fileName' => $fileName, 'thumbYN'=>$thumbYN);
			}
			else
			{
				$post = array('folder' => $folder, 'imagefile' => $data, 'fileName' => $fileName);
			}
			
			$this->url = "http://{$this -> apiHostname}/api/imgupload/imgUpload.php";

			return $this->postBody($post, true);
		}
		
		public function setImgUpload2($data)
		{
			$this->url = "http://{$this -> apiHostname}/api/imgupload/imgUpload.php";

			return $this->postBody($data, true);
		}
	}