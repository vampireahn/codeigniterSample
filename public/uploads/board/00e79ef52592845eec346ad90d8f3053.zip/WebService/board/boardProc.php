<?php
	/** Include files */
	include_once($_SERVER ["DOCUMENT_ROOT"] . "/WebService/conf/inc_Config.php"); // required
	$type = ifilter($_REQUEST["type"], "string");
	if ($type == "")
	{
		$file = $_FILES["file"]["tmp_name"];
		$fileName = $_FILES["file"]["name"];
		$content = $_REQUEST["content"];
		$imgUpload = new ImgUpLoad();
		$handle = fopen($file, "r");
		$data = base64_encode(fread($handle, filesize($file)));
		$formData = array(
			"imagefile" => $data,
			"fileName" => $fileName,
			"content" => $content,
			"folder" => "board"
		);
		//	$request = $imgUpload->setImgUpload("board", $file, $fileName);
		$formData = json_encode($formData);
		$request = $imgUpload->setImgUpload2($formData);
		echo $request["code"] . " " . $request["msg"] . " " . $request["_msg"];
	}
	else if ($type == "get")
	{
		$id = ifilter($_REQUEST["id"], "string");
		$pass = ifilter($_REQUEST["pass"], "string");
		
		$data = array(
			"id" => $id,
			"pass" => $pass
		);
		
		$formData = json_encode($data);
		
		$board = new Board();
		$request = $board->getCheck($formData);
		
		var_dump($request);
	}
	