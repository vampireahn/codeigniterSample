<div>
    <form name="frm" method="post" enctype="multipart/form-data" action="boardProc.php">
        <input type="text" name="content">
        <input type="file" name="file">
        <button type="submit">저장</button>
    </form>
</div>