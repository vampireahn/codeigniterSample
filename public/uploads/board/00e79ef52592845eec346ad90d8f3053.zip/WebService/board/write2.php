
<!DOCTYPE html>
<html>
<body>

<form action="boardProc.php" method="post" enctype="multipart/form-data" align="center">
    <input type="hidden" name="type" value="get">
    ID<input type="text" name="id">
    Pass<input type="password" name="pass">
    <input type="submit" value= "Submit">
</form>
</body>
</html>